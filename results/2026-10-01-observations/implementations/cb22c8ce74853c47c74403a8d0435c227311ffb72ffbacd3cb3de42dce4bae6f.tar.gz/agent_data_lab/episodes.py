"""Controlled source changes over retained, model-authored working artifacts."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import json
from pathlib import Path
import shutil
import subprocess

from .fixtures import dataset_digest,write_json
from .runner import CodexRunner
from .sandbox import Sandbox,TOOL
from .workflow import ARTIFACT_SCHEMA,INSTRUCTIONS,LIBRARIES,read_artifact


CLARIFICATION="""
## Local experiment: fee rule interpretation

An empty categorical restriction list, like null, imposes no restriction.
For an average fee across rules, match only the characteristics named in the
question. Do not filter unspecified characteristics. Give each matching rule
equal weight; this is not an average over observed payments.
"""
STEPS=[
    {'name':'derive','amount':'10','account':'H','category':'Eating Places and Restaurants'},
    {'name':'new-amount','amount':'37.50','account':'H','category':'Eating Places and Restaurants'},
    {'name':'data-change','amount':'37.50','account':'H','category':'Eating Places and Restaurants'},
    {'name':'meaning-change','amount':'37.50','account':'H','category':'Eating Places and Restaurants'},
    {'name':'unrelated-change','amount':'37.50','account':'H','category':'Eating Places and Restaurants'},
    {'name':'move-source','amount':'37.50','account':'H','category':'Eating Places and Restaurants'},
    {'name':'new-category','amount':'12.75','account':'R','category':'Book Stores'},
]


def transition(root,name):
    """Each named transition is applied once, immediately before its task."""
    if name=='data-change':
        rules=json.loads((root/'fees.json').read_text())
        for row in rules:
            if row['card_scheme']=='GlobalCard' and row['ID']%3==0:
                row['rate']+=17
        row=dict(next(r for r in rules if r['card_scheme']=='GlobalCard'))
        row.update(ID=10001,account_type=['H'],merchant_category_code=[5812],rate=41,fixed_amount=0.019)
        rules.append(row)
        (root/'fees.json').write_text(json.dumps(rules,indent=2)+'\n')
    elif name=='meaning-change':
        path=root/'manual.md'
        text=path.read_text().replace('10000','1000')
        text+='\n## Rate unit update\n\nThe rate unit is now one per thousand. The fee formula above applies to all current rules.\n'
        path.write_text(text)
    elif name=='unrelated-change':
        with (root/'manual.md').open('a') as file:
            file.write('\n## Document presentation\n\nThe reporting team now uses a blue cover page. This does not alter fee calculations.\n')
    elif name=='move-source':
        destination=root/'pricing'; destination.mkdir()
        (root/'fees.json').rename(destination/'fee-rules.json')


def reference_answer(root,step,divisor):
    """Independent host calculation; model receives neither this nor the gold."""
    import csv
    category={int(r['mcc']) for r in csv.DictReader((root/'merchant_category_codes.csv').open())
              if r['description']==step['category']}
    if not category: raise ValueError('unknown category in episode')
    path=root/'fees.json'
    if not path.exists(): path=root/'pricing/fee-rules.json'
    rules=json.loads(path.read_text(),parse_float=Decimal)
    matches=[r for r in rules if r['card_scheme']=='GlobalCard'
             and (not r['account_type'] or step['account'] in r['account_type'])
             and (not r['merchant_category_code'] or category.intersection(r['merchant_category_code']))]
    total=sum((Decimal(r['fixed_amount'])+Decimal(r['rate'])*Decimal(step['amount'])/divisor for r in matches),Decimal(0))
    return {'answer':format(total/len(matches),'.6f'),'matching_ids':sorted(r['ID'] for r in matches)}


def question(step):
    return (f"Using the current source documents and data, what is the arithmetic mean GlobalCard fee for a "
            f"transaction of EUR {step['amount']}, for account type {step['account']} and merchant category "
            f"{step['category']}? Match only these specified characteristics; average equally across matching fee rules. "
            "Report EUR with exactly 6 decimal places. Write /scratch/answer.json as instructed. "
            "Previous scripts and notes in /scratch are available for reuse. The sources may have been updated since the previous task.")


def run_episode(args):
    source=Path(args.dataset).resolve()
    output=Path(args.output).resolve(); output.mkdir(parents=True,exist_ok=False)
    implementation=output/'implementation'
    shutil.copytree(Path(__file__).parent,implementation,ignore=shutil.ignore_patterns('__pycache__'))
    manifest={'kind':'retained-work-source-changes','steps':STEPS,'conditions':args.modes.split(','),
        'models':args.models.split(','),'effort':args.effort,'clarification':CLARIFICATION,
        'implementation_sha256':dataset_digest(implementation),
        'dataset':json.loads((source/'manifest.json').read_text()),
        'git_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'replicates':args.replicates,
        'conditions_description':'conversation retains thread and files; workspace retains files but starts a fresh thread per task'}
    write_json(output/'manifest.json',manifest)
    jobs=[(model,mode,replicate) for replicate in range(args.replicates)
          for model in args.models.split(',') for mode in args.modes.split(',')]
    if not set(args.modes.split(','))<={'conversation','workspace'}: raise ValueError('unknown mode')
    tool=dict(TOOL,description=TOOL['description']+' Pandas and DuckDB are installed in Python.')
    def execute(job):
        model,mode,replicate=job; name=f'{model}-{mode}-{replicate}'
        home=output/name; home.mkdir()
        root=home/'source'; shutil.copytree(source/'context',root)
        with (root/'manual.md').open('a') as file: file.write(CLARIFICATION)
        scratch=home/'scratch'; scratch.mkdir()
        host=home/'host'; host.mkdir()
        sandbox=Sandbox(root,scratch,interface=False,libraries=LIBRARIES)
        thread_id=None; divisor=10000; results=[]
        with CodexRunner(host,model,args.effort,args.timeout) as runner:
            for i,step in enumerate(STEPS):
                transition(root,step['name'])
                if step['name']=='meaning-change': divisor=1000
                expected=reference_answer(root,step,divisor)
                stage=home/f'{i}-{step["name"]}'; stage.mkdir()
                write_json(stage/'input.json',{'question':question(step),'expected':expected,
                    'source_sha256':dataset_digest(root),'starting_scratch_sha256':dataset_digest(scratch)})
                (scratch/'answer.json').unlink(missing_ok=True)
                def capture(exchange):
                    with (stage/'trace.jsonl').open('a') as file:
                        file.write(json.dumps(exchange,ensure_ascii=False)+'\n')
                try:
                    result=runner.run(question(step),sandbox,max_calls=60,on_exchange=capture,
                        output_schema=ARTIFACT_SCHEMA,base_instructions=INSTRUCTIONS,tool_spec=tool,
                        thread_id=thread_id if mode=='conversation' else None)
                    thread_id=result['thread_id']
                    artifact=read_artifact(scratch)
                    correct=Decimal(artifact['answer'])==Decimal(expected['answer'])
                    result.update(artifact=artifact,grade={'correct':correct,'expected':expected['answer'],'actual':artifact['answer']},
                                  protocol_valid=not result.get('unexpected_tools'))
                except Exception as error:
                    result={'status':'error','error':type(error).__name__+': '+str(error)}
                write_json(stage/'result.json',result)
                shutil.copytree(scratch,stage/'artifacts',ignore=shutil.ignore_patterns('__pycache__'))
                results.append({k:v for k,v in result.items() if k not in {'trace','messages'}})
                print(json.dumps({'episode':name,'step':step['name'],'status':result['status'],
                    'grade':result.get('grade'),'model_calls':result.get('model_completions')}),flush=True)
                if result['status']!='completed': break
        write_json(home/'summary.json',results)
        return results
    with ThreadPoolExecutor(max_workers=args.workers) as pool: list(pool.map(execute,jobs))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset',default='datasets/dabstep-8afcb4ee')
    parser.add_argument('--output',required=True)
    parser.add_argument('--models',default='gpt-6-astra,gpt-6-luna')
    parser.add_argument('--modes',default='conversation,workspace')
    parser.add_argument('--effort',default='high')
    parser.add_argument('--replicates',type=int,default=1)
    parser.add_argument('--workers',type=int,default=3)
    parser.add_argument('--timeout',type=int,default=900)
    run_episode(parser.parse_args())


if __name__=='__main__': main()
