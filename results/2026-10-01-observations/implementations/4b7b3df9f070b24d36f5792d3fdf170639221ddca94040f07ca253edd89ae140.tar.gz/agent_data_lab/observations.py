"""Source-derived observations, without domain interpretation or model calls."""

from difflib import unified_diff
from hashlib import sha256
import json
from pathlib import Path

from .catalog import Catalog


def source_snapshot(root):
    """The root is the declared query domain; no authority over other sources."""
    root=Path(root).resolve(); result={}
    for path in sorted(root.rglob('*')):
        if not path.is_file(): continue
        content=path.read_bytes()
        entry={'revision':sha256(content).hexdigest(),'bytes':len(content)}
        if len(content)<=65536:
            try: entry['text']=content.decode('utf-8')
            except UnicodeDecodeError: pass
        result[str(path.relative_to(root))]=entry
    return result


def source_changes(before,after):
    changes=[]
    for path in sorted(before.keys()|after.keys()):
        old,new=before.get(path),after.get(path)
        if old is not None and new is not None and old['revision']==new['revision']: continue
        item={'path':path,'change':'added' if old is None else 'removed' if new is None else 'modified',
              'before':old and old['revision'],'after':new and new['revision']}
        if old is not None and new is not None and 'text' in old and 'text' in new:
            diff=''.join(unified_diff(old['text'].splitlines(True),new['text'].splitlines(True),
                fromfile=path+' (previous)',tofile=path+' (current)',n=3))
            item.update(diff=diff[:8000],diff_truncated=len(diff)>8000)
        changes.append(item)
    return {'scope':'all source files under /work; scratch artifacts are excluded',
            'changes':changes,'unchanged_count':len(after)-sum(x['change']!='removed' for x in changes)}


def discover(root,cache,question):
    catalog=Catalog(root,cache)
    try:
        result=catalog.find(question)
        # Internal SQL names are not needed when only passing source observations.
        for item in result['matches']:
            if item['line']==0:
                description=json.loads(item['text'])
                description.pop('table',None)
                item['text']=json.dumps(description,ensure_ascii=False)
        return {'selection':'lexical search over document sections and inferred schemas; not an exhaustive interpretation',
                'observations':result['matches'],'unprofiled':result.get('unprofiled',[])}
    finally: catalog.close()
