"""Generic source inspection and structural text search over native files."""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
import re
import sqlite3

import duckdb
from markdown_it import MarkdownIt


def fingerprint(path: Path) -> str:
    digest=sha256()
    with path.open('rb') as stream:
        while chunk:=stream.read(1024*1024): digest.update(chunk)
    return digest.hexdigest()


def sql_string(value):
    return "'"+str(value).replace("'","''")+"'"


def identifier(value):
    return '"'+str(value).replace('"','""')+'"'


def markdown_sections(text):
    lines=text.splitlines()
    headings=[]
    tokens=MarkdownIt('commonmark').parse(text)
    for i,token in enumerate(tokens):
        if token.type=='heading_open' and token.map is not None:
            headings.append((token.map[0],int(token.tag[1:]),tokens[i+1].content))
    if not headings:
        return [{'line':1,'end_line':len(lines),'heading':'','text':text}]
    result=[]; chain=[]
    if headings[0][0]>0:
        result.append({'line':1,'end_line':headings[0][0],'heading':'','text':'\n'.join(lines[:headings[0][0]])})
    for i,(start,level,title) in enumerate(headings):
        chain=[entry for entry in chain if entry[0]<level]+[(level,title)]
        end=headings[i+1][0] if i+1<len(headings) else len(lines)
        result.append({'line':start+1,'end_line':end,'heading':' / '.join(x[1] for x in chain),
                       'text':'\n'.join(lines[start:end])})
    return result


class Catalog:
    """Profiles and sections are derived; source bytes remain authoritative.

    File locations identify sources in this prototype. A product content owner
    supplies its stable identities when mapping these observations to content.
    """

    def __init__(self, root='/work', cache='/scratch/catalog'):
        self.root=Path(root).resolve(); self.cache=Path(cache).resolve()
        self.cache.mkdir(parents=True,exist_ok=True)
        self.state_path=self.cache/'sources.json'
        self.state=json.loads(self.state_path.read_text()) if self.state_path.exists() else {}
        self.db=duckdb.connect(str(self.cache/'query.duckdb'))
        self.db.execute('CREATE SCHEMA IF NOT EXISTS raw')
        self.index=sqlite3.connect(self.cache/'text.sqlite')
        self.index.execute('CREATE VIRTUAL TABLE IF NOT EXISTS units USING fts5(path UNINDEXED, revision UNINDEXED, start UNINDEXED, end UNINDEXED, heading, body)')
        self.changes=[]
        self.refresh()

    def refresh(self):
        current={str(path.relative_to(self.root)):path for path in self.root.rglob('*')
                 if path.is_file() and not any(part.startswith('.') for part in path.relative_to(self.root).parts)}
        changes=[]
        for location in set(self.state)-set(current):
            previous=self.state.pop(location)
            if previous.get('table'):
                self.db.execute('DROP VIEW IF EXISTS '+previous['table'])
            self.index.execute('DELETE FROM units WHERE path=?',(location,))
            changes.append({'path':location,'change':'removed'})
        for location,path in current.items():
            revision=fingerprint(path)
            previous=self.state.get(location)
            if previous is None or previous.get('revision')!=revision:
                profile={'path':location,'revision':revision,'bytes':path.stat().st_size,
                         'format':path.suffix.lower().lstrip('.')}
                self.index.execute('DELETE FROM units WHERE path=?',(location,))
                try:
                    self._profile(path,profile)
                except (OSError,UnicodeError,ValueError,duckdb.Error) as error:
                    profile['error']=str(error)
                self.state[location]=profile
                changes.append({'path':location,'change':'new' if previous is None else 'modified'})
            self._register(path,self.state[location])
        self.index.commit()
        self.state_path.write_text(json.dumps(self.state,ensure_ascii=False,indent=2,default=str)+'\n')
        self.changes=changes
        return changes

    def _expression(self,path):
        if path.suffix.lower()=='.csv': return f'read_csv_auto({sql_string(path)}, sample_size=-1)'
        if path.suffix.lower() in {'.json','.jsonl','.ndjson'}: return f'read_json_auto({sql_string(path)}, sample_size=-1)'
        if path.suffix.lower()=='.parquet': return f'read_parquet({sql_string(path)})'
        return None

    def _profile(self,path,profile):
        expression=self._expression(path)
        if expression:
            columns=self.db.sql(f'DESCRIBE SELECT * FROM {expression}').fetchall()
            profile['columns']=[{'name':r[0],'type':r[1]} for r in columns]
            profile['rows']=self.db.sql(f'SELECT count(*) FROM {expression}').fetchone()[0]
            relation=self.db.sql(f'SELECT * FROM {expression} LIMIT 2')
            profile['sample']=[dict(zip(relation.columns,row)) for row in relation.fetchall()]
            profile['table']='raw.'+identifier(profile['path'])
            profile['schema_origin']='DuckDB inference over the complete source'
            description=json.dumps({'path':profile['path'],'table':profile['table'],
                                    'columns':profile['columns']},ensure_ascii=False)
            self.index.execute('INSERT INTO units VALUES (?,?,?,?,?,?)',
                (profile['path'],profile['revision'],0,0,profile['path'],description))
        elif path.suffix.lower() in {'.md','.txt','.rst'}:
            text=path.read_text()
            sections=markdown_sections(text) if path.suffix.lower()=='.md' else [{'line':1,'end_line':len(text.splitlines()),'heading':'','text':text}]
            profile['outline']=[{key:section[key] for key in ['line','end_line','heading']} for section in sections]
            for section in sections:
                self.index.execute('INSERT INTO units VALUES (?,?,?,?,?,?)',
                    (profile['path'],profile['revision'],section['line'],section['end_line'],section['heading'],section['text']))
        else:
            profile['error']='No structural profile for this format; native file remains available.'

    def _register(self,path,profile):
        if 'table' in profile and 'error' not in profile:
            self.db.execute(f'CREATE OR REPLACE VIEW {profile["table"]} AS SELECT * FROM {self._expression(path)}')

    def sources(self):
        """Return format, schema/sample or outline, observed version and failures."""
        self.refresh()
        return list(self.state.values())

    def find(self,query,limit=5):
        """Search document sections and table schemas, not all table cell values."""
        self.refresh()
        terms=re.findall(r'\w+',query)
        if not terms: return {'matches':[],'searches':'document sections and schemas'}
        expression=' OR '.join('"'+term.replace('"','""')+'"' for term in terms)
        rows=self.index.execute('SELECT path,revision,start,end,heading,body,bm25(units) FROM units WHERE units MATCH ? ORDER BY bm25(units),path,start LIMIT ?',
                                (expression,limit)).fetchall()
        return {'matches':[{'path':row[0],'revision':row[1],'line':row[2],'end_line':row[3],
                            'heading':row[4],'text':row[5]} for row in rows],
                'searches':'document sections and table schemas; use SQL for table values',
                'unprofiled':[{'path':p['path'],'error':p['error']} for p in self.state.values() if 'error' in p]}

    def read(self,path,start=1,end=None,revision=None):
        target=(self.root/path).resolve()
        if not target.is_relative_to(self.root): raise ValueError('path outside source root')
        observed=fingerprint(target)
        if revision is not None and revision!=observed: raise ValueError('source revision changed')
        text=target.read_text().splitlines()
        return {'path':path,'revision':observed,'line':start,'text':'\n'.join(text[start-1:end])}

    def sql(self,query,params=None):
        """Native DuckDB query over table names returned by sources()."""
        self.refresh()
        result=self.db.execute(query,params or [])
        if result.description is None: return []
        columns=[item[0] for item in result.description]
        return [dict(zip(columns,row)) for row in result.fetchall()]

    def close(self):
        self.db.close(); self.index.close()
