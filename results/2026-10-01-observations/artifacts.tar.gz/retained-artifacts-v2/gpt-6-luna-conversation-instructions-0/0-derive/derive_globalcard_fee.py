import csv, json
from decimal import Decimal
from pathlib import Path

fees = json.loads(Path('/work/fees.json').read_text())
with Path('/work/merchant_category_codes.csv').open(newline='') as f:
    mccs = {int(row['mcc']) for row in csv.DictReader(f)
            if row['description'] == 'Eating Places and Restaurants'}
assert len(mccs) == 1, f'Expected one exact MCC mapping, got {mccs}'
mcc = next(iter(mccs))
# Match only the requested rule characteristics: scheme, account type and MCC.
# Other rule fields remain unconstrained; null only is documented as wildcard.
matches = [r for r in fees
           if r['card_scheme'] == 'GlobalCard'
           and r['account_type'] is not None and 'H' in r['account_type']
           and r['merchant_category_code'] is not None and mcc in r['merchant_category_code']]
assert matches, 'No matching fee rules'
amount = Decimal('10')
values = [Decimal(str(r['fixed_amount'])) + Decimal(str(r['rate'])) * amount / Decimal('10000')
          for r in matches]
mean = sum(values) / Decimal(len(values))
# retain evidence of the individual rules/calculations for later reuse
method = (f"Read current fee rules and MCC lookup; exact MCC description maps to {mcc}. "
          "Selected GlobalCard rules whose account_type contains H and merchant_category_code contains that MCC; "
          "left all other fee-rule characteristics unconstrained. Computed each fee as fixed_amount + rate*10/10000 "
          "and took an equal-weight arithmetic mean across matching rules.")
out = {'answer': f'EUR {mean:.6f}', 'method': method,
       'sources': ['/work/fees.json', '/work/merchant_category_codes.csv']}
Path('/scratch/results/0-derive.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
Path('/scratch/globalcard_fee_evidence.json').write_text(json.dumps({
    'mcc': mcc,
    'matching_rules': [{'ID': r['ID'], 'fixed_amount': r['fixed_amount'], 'rate': r['rate'], 'fee_eur': str(v)}
                       for r, v in zip(matches, values)],
    'count': len(matches), 'mean_eur': str(mean), 'amount_eur': '10',
    'matched_characteristics': {'card_scheme': 'GlobalCard', 'account_type': 'H', 'mcc_description': 'Eating Places and Restaurants'}
}, indent=2) + '\n')
print(Path('/scratch/results/0-derive.json').read_text())
print(Path('/scratch/globalcard_fee_evidence.json').read_text())
