import csv,json
from decimal import Decimal
from pathlib import Path
root=Path('/work')
with (root/'merchant_category_codes.csv').open() as f:
    categories=[r for r in csv.DictReader(f) if r['description']=='Book Stores']
assert len(categories)==1
mcc=int(categories[0]['mcc'])
rules=json.loads((root/'pricing/fee-rules.json').read_text(),parse_float=Decimal)
def matches(restriction,value):
    return restriction is None or restriction == [] or (value in restriction if isinstance(restriction,list) else restriction==value)
matched=[r for r in rules if matches(r['card_scheme'],'GlobalCard') and matches(r['account_type'],'R') and matches(r['merchant_category_code'],mcc)]
fees=[Decimal(r['fixed_amount'])+Decimal(r['rate'])*Decimal('12.75')/Decimal(1000) for r in matched]
total=sum(fees)
mean=total/len(fees)
result={'answer':f'EUR {mean:.6f}','method':f'Read current sources. Book Stores maps to MCC {mcc}; account R is Enterprise - Retail. Match only GlobalCard, account type R, and MCC {mcc}, treating null and empty categorical lists as unrestricted. Do not filter any unspecified characteristics. For each of the {len(matched)} matching fee rules, calculate fixed_amount + rate × 12.75 / 1000 using decimal arithmetic. Sum of fees = EUR {total}; equally weighted arithmetic mean = {total} / {len(matched)} = EUR {mean}, rounded to exactly six decimal places.','sources':['/work/manual.md','/work/merchant_category_codes.csv','/work/pricing/fee-rules.json']}
Path('/scratch/answer.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
print('Matched IDs:',[r['ID'] for r in matched])
