# 来源目录与工作表示

Python：`from agent_data_lab.catalog import Catalog; c=Catalog('/work','/scratch/catalog')`。
原文件、Pandas、DuckDB 与普通 shell 继续可用，工具不解释业务规则。

- `c.sources()` 返回来源路径、格式、实际版本、列类型、行数、样本；文档返回标题层次。结构由原文件自动提取。
- `c.find(query, limit=5)` 搜索文档分段和表结构，直接返回所在段落、路径、行号、版本；不搜索所有表格单元值。
- `c.read(path,start=1,end=None,revision=None)` 读取文本行区间（1-based），指定旧 revision 时拒绝混用新版本。
- `c.sql(query,params=None)` 执行原生 DuckDB SQL。表名见 sources()，例如 `raw."payments.csv"`、`raw."fees.json"`。
  返回行字典列表，能在程序中继续处理而不向模型打印全部内容。
- 同一个 cache 中的 DuckDB 数据库保留自行建立的 main schema 视图或表。
  原始来源位于 raw schema；普通 SQL VIEW 在查询时读取当前文件，自己材料化的 TABLE 由创建者维护。
- `c.refresh()` 检查新建、修改和移除的来源；profile/index 是派生结果。
- `c.close()` 关闭连接。

解释后的业务规则、组合程序及任务结果可保留为普通文件或原生 SQL 视图，不要求固定表示。
