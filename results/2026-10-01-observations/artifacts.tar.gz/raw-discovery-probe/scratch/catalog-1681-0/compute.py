import csv,json
from decimal import Decimal
from datetime import date,timedelta
root='/work/'
merchant=next(m for m in json.load(open(root+'merchant_data.json')) if m['merchant']=='Belles_cookbook_store')
p=[r for r in csv.DictReader(open(root+'payments.csv')) if r['merchant']==merchant['merchant'] and r['year']=='2023']
d=[r for r in p if int(r['day_of_year'])==10]
month=[r for r in p if 1<=int(r['day_of_year'])<=31]
volume=sum(Decimal(r['eur_amount']) for r in month)
fraud=sum(Decimal(r['eur_amount']) for r in month if r['has_fraudulent_dispute']=='True')
fraction=fraud/volume

def number(s):
 s=s.strip()
 for suffix,mult in [('%',Decimal('.01')),('k',1000),('m',1000000)]:
  if s.endswith(suffix):return Decimal(s[:-1])*mult
 return Decimal(s)
def range_match(value,rule):
 if rule is None:return True
 if rule.startswith('<'):return value<number(rule[1:])
 if rule.startswith('>'):return value>number(rule[1:])
 if '-' in rule:
  a,b=rule.split('-');return number(a)<=value<=number(b)
 return str(value)==rule
def listed(value,rule):return not rule or value in rule
def scalar(value,rule):return rule is None or value==rule

def matches(r,t):
 return (listed(merchant['account_type'],r['account_type'])
 and listed(merchant['merchant_category_code'],r['merchant_category_code'])
 and range_match(Decimal(merchant['capture_delay']),r['capture_delay'])
 and range_match(volume,r['monthly_volume'])
 and range_match(fraction,r['monthly_fraud_level'])
 and scalar(t['card_scheme'],r['card_scheme'])
 and scalar(t['is_credit']=='True',r['is_credit'])
 and listed(t['aci'],r['aci'])
 and scalar(t['issuing_country']==t['acquirer_country'],r['intracountry']))
fees=json.load(open(root+'fees.json'))
matched=[r for r in fees if any(matches(r,t) for t in d)]
ids=sorted({r['ID'] for r in matched})
print('volume',volume,'fraud',fraud,'ratio',fraction,'transactions',len(d))
print('IDs',ids)
for r in matched: print(r)
answer={
 'answer':', '.join(map(str,ids)),
 'method':('Interpreted “the 10th of the year 2023” as day_of_year=10 (10 January 2023). Selected the 37 payments for Belles_cookbook_store on that day. Computed January merchant volume from all 1,201 payments as EUR 113,260.42 and fraudulent-dispute volume as EUR 11,680.62 (fraudulent volume / total volume = '+str(fraction*100)+'%). Matched each fee rule against merchant account type R, MCC 5942, capture delay 1 day (<3), the calendar-month volume and fraud rate, and each payment’s card scheme, credit indicator, ACI and domestic status (issuing_country equals acquirer_country). Null fields and empty category lists were treated as unrestricted. Returned the numerically sorted distinct IDs matching at least one payment.'),
 'sources':[root+x for x in ['manual.md','payments-readme.md','merchant_data.json','payments.csv','fees.json']]
}
with open('/scratch/answer.json','w') as f:json.dump(answer,f,ensure_ascii=False,indent=2)
