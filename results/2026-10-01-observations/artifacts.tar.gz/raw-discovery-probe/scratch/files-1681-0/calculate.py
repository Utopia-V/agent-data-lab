import json
import pandas as pd
p=pd.read_csv('/work/payments.csv')
p=p[(p.merchant=='Belles_cookbook_store') & (p.year==2023)].copy()
p['month']=(pd.Timestamp('2023-01-01')+pd.to_timedelta(p.day_of_year-1,unit='D')).dt.month
merchant=next(x for x in json.load(open('/work/merchant_data.json')) if x['merchant']=='Belles_cookbook_store')
fees=json.load(open('/work/fees.json'))
def bound(rule,x):
 if rule is None:return True
 def num(s):
  return float(s.replace('%','').replace('k','e3').replace('m','e6'))
 if rule.startswith('<'):return x<num(rule[1:])
 if rule.startswith('>'):return x>num(rule[1:])
 lo,hi=map(num,rule.split('-'));return lo<=x<=hi

def calc(month,day=None):
 q=p[p.month==month];volume=q.eur_amount.sum();fraud=q.loc[q.has_fraudulent_dispute,'eur_amount'].sum()/volume*100
 if day is not None:q=q[q.day_of_year==day]
 ids=[]
 for f in fees:
  if any(f[k] and merchant[k] not in f[k] for k in ['account_type','merchant_category_code']):continue
  if f['capture_delay'] is not None and f['capture_delay']!='<3':continue
  if not bound(f['monthly_volume'],volume) or not bound(f['monthly_fraud_level'],fraud):continue
  t=q[q.card_scheme==f['card_scheme']]
  if f['aci']:t=t[t.aci.isin(f['aci'])]
  if f['is_credit'] is not None:t=t[t.is_credit==f['is_credit']]
  if f['intracountry'] is not None:t=t[(t.issuing_country==t.acquirer_country)==bool(f['intracountry'])]
  if len(t):ids.append(f['ID'])
 return ids,volume,fraud,len(q)
for mo,day in [(10,None),(1,10)]:print(mo,day,calc(mo,day))
ids,volume,fraud,n=calc(10)
result={'answer':', '.join(map(str,ids)),'method':f'Interpreted the 10th of 2023 as October 2023. Converted day_of_year to calendar month and selected Belles_cookbook_store payments in October (days 274–304). Monthly total volume is EUR {volume:.2f}; fraudulent-dispute volume divided by total volume is {fraud:.10f}%. Matched fee rules against merchant account type R, MCC 5942 and capture delay 1 day (<3), the monthly volume and fraud bands, and the card scheme, credit indicator, ACI and issuer/acquirer-country equality of October transactions. Null values and empty categorical lists are treated as unrestricted. Returned the sorted distinct IDs matching at least one transaction.','sources':['/work/manual.md','/work/payments-readme.md','/work/merchant_data.json','/work/payments.csv','/work/fees.json']}
json.dump(result,open('/scratch/answer.json','w'),indent=2)
