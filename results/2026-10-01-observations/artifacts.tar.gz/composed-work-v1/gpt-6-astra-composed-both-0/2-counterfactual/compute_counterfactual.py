import csv,json
from decimal import Decimal
from pathlib import Path
rule=next(r for r in json.load(open('/work/fees.json'),parse_float=Decimal) if r['ID']==384)
# Current rule has only three restrictions; assert this before using the direct filter.
assert all(rule[k] is None or rule[k]==[] for k in ('account_type','capture_delay','monthly_fraud_level','monthly_volume','merchant_category_code','intracountry'))
with open('/work/payments.csv') as f:
 rows=[r for r in csv.DictReader(f) if r['merchant']=='Belles_cookbook_store' and int(r['year'])==2023 and 1<=int(r['day_of_year'])<=31]
matched=[r for r in rows if r['card_scheme']==rule['card_scheme'] and (r['is_credit']=='True')==rule['is_credit'] and r['aci'] in rule['aci']]
amount=sum((Decimal(r['eur_amount']) for r in matched),Decimal(0))
old=sum((rule['fixed_amount']+rule['rate']*Decimal(r['eur_amount'])/10000 for r in matched),Decimal(0))
new=sum((rule['fixed_amount']+Decimal(r['eur_amount'])/10000 for r in matched),Decimal(0))
difference=new-old
assert difference==(1-rule['rate'])*amount/10000
result={'answer':format(difference,'.14f'),'method':f'读取当前 fees.json 中规则384：rate={rule["rate"]}，fixed_amount={rule["fixed_amount"]}，仅限制卡组织NexPay、is_credit=true、ACI属于C或B，其余字段为空或null，均不限制。筛选Belles_cookbook_store在2023年1月的全部记录（year=2023且day_of_year为1至31），包含被拒交易，匹配{len(matched)}笔，交易金额合计{amount}欧元。按fee=fixed_amount+rate×eur_amount/10000，以Decimal按原始十进制金额精确计算，不舍入中间结果。仅将规则384的rate反事实设为1，旧费用总和{old}欧元，新费用总和{new}欧元，差值=(1-{rule["rate"]})×{amount}/10000={difference}欧元；其他规则不参与，原始数据未修改。','sources':['/work/manual.md','/work/fees.json','/work/payments.csv']}
Path('/scratch/results/2-counterfactual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
