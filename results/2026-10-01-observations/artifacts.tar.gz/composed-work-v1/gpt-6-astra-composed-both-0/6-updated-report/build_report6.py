from pathlib import Path
# Reuse the established matcher, without executing prior output-writing code.
matcher = Path('/scratch/compute_day.py').read_text().split('counts={')[0]
exec(matcher)
# Read fee decimals exactly, rather than through binary floating point.
fees = json.loads(Path('/work/fees.json').read_text(), parse_float=D)
rows=[]
for fee in sorted(fees, key=lambda f:f['ID']):
    matched=[r for r in month if match(fee,r)]
    if not matched:
        continue
    amount=sum((D(r['eur_amount']) for r in matched),D(0))
    total_fee=sum((fee['fixed_amount']+D(fee['rate'])*D(r['eur_amount'])/D(10000) for r in matched),D(0))
    assert total_fee == len(matched)*fee['fixed_amount']+D(fee['rate'])*amount/D(10000)
    rows.append(dict(fee_id=fee['ID'],card_scheme=fee['card_scheme'],transactions=len(matched),amount_eur=format(amount,'.2f'),fee_eur=format(total_fee,'.6f')))
report=Path('/scratch/reports'); report.mkdir(exist_ok=True)
csv_path=report/'6.csv'; html_path=report/'6.html'
fields=['fee_id','card_scheme','transactions','amount_eur','fee_eur']
with csv_path.open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields)
    writer.writeheader(); writer.writerows(rows)
payload=json.dumps(rows,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
html='''<!doctype html>
<html lang="zh-CN">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Belles_cookbook_store · 2023年1月逐规则费用审计</title>
<style>
:root{font-family:system-ui,sans-serif;color:#172c3b;background:#f3f6f8}body{max-width:1100px;margin:40px auto;padding:0 24px}h1{font-size:1.8rem}p{line-height:1.7}.note{border-left:4px solid #247684;padding:12px 18px;background:white}.controls{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:24px 0}select{padding:8px 12px;font:inherit;border:1px solid #8497a4;border-radius:6px;background:white}.table-wrap{overflow:auto;border:1px solid #d2dce2;border-radius:8px}table{border-collapse:collapse;width:100%;background:white}th,td{padding:11px 16px;border-bottom:1px solid #e2e8ec;text-align:right;font-variant-numeric:tabular-nums}th{background:#183d50;color:white}th:nth-child(2),td:nth-child(2){text-align:left}tbody tr:nth-child(even){background:#f5f9fb}caption{text-align:left;padding:14px;font-weight:600}footer{margin:24px 0;color:#4f6572;font-size:.9rem}
</style></head><body>
<h1>Belles_cookbook_store</h1>
<p>2023年1月 · 逐规则费用审计（欧元）</p>
<p class="note">每行独立统计一个适用规则。交易可能同时匹配多个规则，行间金额与费用不可相加为总账单。</p>
<p>范围：2023年1月1日至31日全部 __COUNT__ 笔交易（含拒绝交易）。自然月交易金额 €__VOLUME__；欺诈争议金额 €__FRAUD__；欺诈金额占比约 __PERCENT__%。商户账户类型 R，MCC 5942，捕获延迟 1 天。</p>
<div class="controls"><label for="scheme-filter">卡组织</label><select id="scheme-filter"><option value="">全部卡组织</option></select><span>当前行数：<strong id="row-count" aria-live="polite">0</strong></span></div>
<div class="table-wrap"><table id="fees"><caption>适用费用规则</caption><thead><tr><th scope="col">fee_id</th><th scope="col">card_scheme</th><th scope="col">transactions</th><th scope="col">amount_eur</th><th scope="col">fee_eur</th></tr></thead><tbody></tbody></table></div>
<noscript>请启用 JavaScript 以查看和筛选嵌入的审计数据。</noscript>
<footer>计算：每笔费用 = fixed_amount + rate × eur_amount / 10000。各规则对所有匹配交易独立求和，计算中不舍入；金额显示 2 位小数，费用显示 6 位小数，末位采用半偶舍入。空分类列表和 null 不限制匹配。来源：payments.csv、merchant_data.json、fees.json、manual.md。数据已内嵌，无需网络连接。</footer>
<script id="fee-data" type="application/json">__DATA__</script>
<script>
'use strict';
const rows=JSON.parse(document.getElementById('fee-data').textContent);
const select=document.getElementById('scheme-filter');
const body=document.querySelector('#fees tbody');
const fields=['fee_id','card_scheme','transactions','amount_eur','fee_eur'];
const schemeName=r=>r.card_scheme===null?'全部（规则不限卡组织）':r.card_scheme;
for(const scheme of [...new Set(rows.map(schemeName))].sort()){
 const option=document.createElement('option');option.value=scheme;option.textContent=scheme;select.appendChild(option);
}
function render(){
 const filtered=rows.filter(r=>select.value===''||schemeName(r)===select.value);
 body.replaceChildren();
 for(const row of filtered){
  const tr=document.createElement('tr');
  for(const field of fields){const td=document.createElement('td');td.textContent=field==='card_scheme'?schemeName(row):String(row[field]);tr.appendChild(td);}
  body.appendChild(tr);
 }
 document.getElementById('row-count').textContent=String(filtered.length);
}
select.addEventListener('change',render);render();
</script></body></html>
'''
for key,value in {'__COUNT__':str(len(month)),'__VOLUME__':format(volume,'.2f'),'__FRAUD__':format(fraud,'.2f'),'__PERCENT__':format(100*fraud/volume,'.6f'),'__DATA__':payload}.items():html=html.replace(key,value)
html_path.write_text(html)
result={'answer':'ready','method':f'重新读取当前来源，使用2023年1月1日至31日该商户全部{len(month)}笔交易，精确计算月交易金额{volume}欧元、欺诈争议金额{fraud}欧元；欺诈比例阈值以Decimal交叉相乘比较。按商户账户类型、MCC、捕获延迟和月金额、月欺诈比例，以及各交易卡组织、信用卡标志、ACI、发卡国与收单国是否相同匹配规则，null与空分类列表不限制。每个至少匹配一笔交易的规则独立统计交易数、金额及fixed_amount + rate × eur_amount / 10000费用之和，不合并重叠规则。结果按fee_id数值升序排列，共'+str(len(rows))+'行。同一组表数据写入CSV并嵌入HTML的fee-data，用于前端筛选及显示。金额和费用分别以2位、6位小数输出，计算过程不舍入。','sources':['/work/manual.md','/work/merchant_data.json','/work/payments.csv','/work/fees.json'],'artifacts':{'csv':str(csv_path),'html':str(html_path)}}
Path('/scratch/results/6-updated-report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
# Validate parity of both delivered representations.
import re
embedded=json.loads(re.search(r'<script id="fee-data" type="application/json">(.*?)</script>',html,re.S).group(1))
assert embedded==rows
with csv_path.open() as f: saved=list(csv.DictReader(f))
assert len(saved)==len(rows)
for a,b in zip(saved,rows):
    assert all(a[k]==('' if b[k] is None else str(b[k])) for k in fields)
    assert re.fullmatch(r'-?\d+\.\d{2}',a['amount_eur'])
    assert re.fullmatch(r'-?\d+\.\d{6}',a['fee_eur'])
assert len({r['fee_id'] for r in rows})==len(rows)
print(json.dumps(result,ensure_ascii=False,indent=2))
print('CSV preview:',csv_path.read_text()[:1000])
