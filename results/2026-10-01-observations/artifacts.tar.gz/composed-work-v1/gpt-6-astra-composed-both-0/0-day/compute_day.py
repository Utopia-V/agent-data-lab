import csv,json
from decimal import Decimal as D
from pathlib import Path
merchant='Belles_cookbook_store'
meta=next(m for m in json.load(open('/work/merchant_data.json')) if m['merchant']==merchant)
fees=json.load(open('/work/fees.json'))
with open('/work/payments.csv') as f:
 month=[r for r in csv.DictReader(f) if r['merchant']==merchant and int(r['year'])==2023 and 1<=int(r['day_of_year'])<=31]
volume=sum((D(r['eur_amount']) for r in month),D(0))
fraud=sum((D(r['eur_amount']) for r in month if r['has_fraudulent_dispute']=='True'),D(0))
day=[r for r in month if int(r['day_of_year'])==10]
def num(s):
 s=s.replace('%','')
 return D(s[:-1])*{'k':1000,'m':1000000}[s[-1]] if s[-1:] in ('k','m') else D(s)
def interval(rule,value):
 if rule is None:return True
 if rule.startswith('<'):return value<num(rule[1:])
 if rule.startswith('>'):return value>num(rule[1:])
 lo,hi=map(num,rule.split('-'))
 return lo<=value<=hi
def member(rule,value):return not rule or value in rule
def match(f,r):
 if not member(f['account_type'],meta['account_type']):return False
 if not member(f['merchant_category_code'],meta['merchant_category_code']):return False
 c=f['capture_delay']
 if c is not None:
  if c in ('immediate','manual'):
   if c!=meta['capture_delay']:return False
  elif not interval(c,D(meta['capture_delay'])):return False
 if not interval(f['monthly_volume'],volume):return False
 # Compare percentage bounds via exact cross multiplication, avoiding division rounding.
 fr=f['monthly_fraud_level']
 if fr:
  v=100*fraud
  if fr.startswith('<') and not v<num(fr[1:])*volume:return False
  if fr.startswith('>') and not v>num(fr[1:])*volume:return False
  if '-' in fr:
   lo,hi=map(num,fr.split('-'))
   if not lo*volume<=v<=hi*volume:return False
 if f['card_scheme'] is not None and f['card_scheme']!=r['card_scheme']:return False
 if f['is_credit'] is not None and f['is_credit']!=(r['is_credit']=='True'):return False
 if not member(f['aci'],r['aci']):return False
 if f['intracountry'] is not None and bool(f['intracountry'])!=(r['issuing_country']==r['acquirer_country']):return False
 return True
counts={f['ID']:sum(match(f,r) for r in day) for f in fees}
ids=sorted(i for i,n in counts.items() if n)
answer=','.join(map(str,ids))
result={'answer':answer,'method':f'重新读取当前来源，按 manual.md 的规则，使用该商户2023年1月全部 {len(month)} 笔交易计算自然月金额 {volume} 欧元及欺诈争议金额 {fraud} 欧元，欺诈率为100×欺诈金额/总金额（约 {100*fraud/volume}%）。金额使用Decimal精确求和，百分比阈值以交叉相乘比较，不舍入中间值。将2023年1月10日全部 {len(day)} 笔交易逐笔与所有费用规则匹配：商户账户类型R、MCC 5942、捕获延迟1天（<3），以及卡组织、信用/借记、ACI和发卡国与收单国是否相同；null与空分类列表均不限制。保留至少匹配一笔交易的规则ID，去重后按数值升序排列。','sources':['/work/manual.md','/work/merchant_data.json','/work/payments.csv','/work/fees.json']}
path=Path('/scratch/results/0-day.json')
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
print('match_counts', {i:counts[i] for i in ids})
