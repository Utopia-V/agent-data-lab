import csv,json
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

merchant='Belles_cookbook_store'
fees=json.load(open('/work/fees.json'), parse_float=Decimal)
profile=next(m for m in json.load(open('/work/merchant_data.json')) if m['merchant']==merchant)
with open('/work/payments.csv',newline='') as f:
    month=[r for r in csv.DictReader(f) if r['merchant']==merchant and int(r['year'])==2023 and 1<=int(r['day_of_year'])<=31]
volume=sum((Decimal(r['eur_amount']) for r in month),Decimal(0))
fraud=sum((Decimal(r['eur_amount']) for r in month if r['has_fraudulent_dispute']=='True'),Decimal(0))
fraud_pct=100*Fraction(fraud)/Fraction(volume)

def number(s):
    s=s.replace('%','')
    multiplier=1
    if s[-1:] in ('k','m'):
        multiplier={'k':1000,'m':1000000}[s[-1]]
        s=s[:-1]
    return Fraction(Decimal(s))*multiplier

def in_range(value,restriction):
    if restriction is None:return True
    if restriction.startswith('<'):return value<number(restriction[1:])
    if restriction.startswith('>'):return value>number(restriction[1:])
    low,high=restriction.split('-')
    return number(low)<=value<=number(high)

def category(value,restriction):
    return restriction is None or restriction==[] or (value in restriction if isinstance(restriction,list) else value==restriction)

def capture(restriction):
    if restriction is None:return True
    value=profile['capture_delay']
    if restriction in ('manual','immediate'):return value==restriction
    return value not in ('manual','immediate') and in_range(Fraction(value),restriction)

candidates=[r for r in fees if category(profile['account_type'],r['account_type']) and category(profile['merchant_category_code'],r['merchant_category_code']) and capture(r['capture_delay']) and in_range(Fraction(volume),r['monthly_volume']) and in_range(fraud_pct,r['monthly_fraud_level'])]
from html import escape

audit=[]
for rule in sorted(candidates,key=lambda r:r['ID']):
    rows=[p for p in month if category(p['card_scheme'],rule['card_scheme']) and category(p['is_credit']=='True',rule['is_credit']) and category(p['aci'],rule['aci']) and category(p['issuing_country']==p['acquirer_country'],rule['intracountry'])]
    if not rows: continue
    amount=sum((Decimal(p['eur_amount']) for p in rows),Decimal(0))
    fee=sum((Decimal(rule['fixed_amount'])+Decimal(rule['rate'])*Decimal(p['eur_amount'])/Decimal(10000) for p in rows),Decimal(0))
    assert fee == len(rows)*Decimal(rule['fixed_amount'])+Decimal(rule['rate'])*amount/Decimal(10000)
    audit.append(dict(fee_id=rule['ID'],card_scheme=rule['card_scheme'],transactions=len(rows),amount_eur=f'{amount:.2f}',fee_eur=f'{fee:.6f}'))

def preserve(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        i=1
        while path.with_name(f'{path.stem}.previous-{i}{path.suffix}').exists():i+=1
        path.with_name(f'{path.stem}.previous-{i}{path.suffix}').write_bytes(path.read_bytes())

csv_path=Path('/scratch/reports/5.csv')
html_path=Path('/scratch/reports/5.html')
result_path=Path('/scratch/results/5-report.json')
for p in (csv_path,html_path,result_path):preserve(p)
fields=['fee_id','card_scheme','transactions','amount_eur','fee_eur']
with csv_path.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields)
    w.writeheader()
    w.writerows(audit)
method=f'依据当前原始资料，筛选 Belles_cookbook_store 在 2023 年 1 月（day_of_year 1—31）的全部 {len(month)} 笔交易，包含拒绝交易且不去重。月交易金额 {volume} EUR，欺诈争议金额 {fraud} EUR；月欺诈百分比按 100×欺诈金额/月交易金额计算（约 {float(fraud_pct):.10f}%），以有理数精确比较阈值。商户属性 account_type=R、merchant_category_code=5942、capture_delay=1。null 和空分类列表不限制；逐项匹配商户属性、月度阈值及交易的 card_scheme、is_credit、aci、intracountry。每个至少匹配一笔交易的规则独立统计交易数、交易金额以及费用；单笔费用为 fixed_amount + rate×eur_amount/10000。以 Decimal 精确累计，不对中间金额或单笔费用舍入；最终金额显示 2 位小数、费用显示 6 位小数（ROUND_HALF_EVEN）。按 fee_id 数值升序输出 {len(audit)} 行；重叠规则不合计为总账单。CSV 和 HTML 内嵌 JSON 使用同一份计算结果。'
data=json.dumps(audit,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
page='''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Belles_cookbook_store · 2023 年 1 月逐规则费用审计</title>
<style>
:root{font-family:system-ui,sans-serif;color:#1c2b3b;background:#f3f6fa}body{margin:0;padding:32px 20px}main{max-width:1100px;margin:auto}h1{font-size:26px;line-height:1.4}p{line-height:1.75}.note{border-left:4px solid #be6c17;background:#fff6e9;padding:12px 18px}.toolbar{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:24px 0 14px}select{font:inherit;padding:9px 12px;border:1px solid #718096;border-radius:6px;background:white}.table-wrap{overflow-x:auto;background:white;border:1px solid #d4dde8;border-radius:8px}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th,td{padding:12px 16px;border-bottom:1px solid #e2e8f0;text-align:right;white-space:nowrap}th{background:#183c57;color:white}th:nth-child(2),td:nth-child(2){text-align:left}tbody tr:nth-child(even){background:#f7f9fc}tbody tr:hover{background:#eaf2fb}details{margin-top:24px;background:white;padding:16px;border:1px solid #d4dde8;border-radius:8px}summary{cursor:pointer;font-weight:600}.sources{color:#526174;font-size:14px}noscript{color:#9a3412}@media print{body{background:white;padding:0}.toolbar{display:none}th{background:#edf2f7;color:black}}
</style>
</head><body><main>
<h1>Belles_cookbook_store<br>2023 年 1 月逐规则费用审计</h1>
<p>期间：2023-01-01 至 2023-01-31。币种：EUR。规则按 fee_id 数值升序排列。</p>
<p class="note">每行独立呈现一个适用规则。相同交易可能匹配多个规则；本表不是账单，不将重叠规则的费用合计。</p>
<div class="toolbar"><label for="scheme-filter">card_scheme</label><select id="scheme-filter"><option value="">全部卡组织</option></select><span>当前行数：<output id="row-count" aria-live="polite">0</output></span></div>
<div class="table-wrap"><table id="fees"><caption style="text-align:left;padding:12px 16px">适用规则及其匹配交易统计</caption><thead><tr><th scope="col">fee_id</th><th scope="col">card_scheme</th><th scope="col">transactions</th><th scope="col">amount_eur</th><th scope="col">fee_eur</th></tr></thead><tbody></tbody></table></div>
<noscript>请启用 JavaScript 以显示内嵌数据及筛选表格。相同数据另存于 5.csv。</noscript>
<details open><summary>计算口径与来源</summary><p>__METHOD__</p><p class="sources">来源：/work/manual.md、/work/merchant_data.json、/work/payments.csv、/work/payments-readme.md、/work/fees.json。此页面为自包含快照，不加载任何网络资源。</p></details>
<script id="fee-data" type="application/json">__DATA__</script>
<script>
'use strict';
const data = JSON.parse(document.getElementById('fee-data').textContent);
const filter = document.getElementById('scheme-filter');
const body = document.querySelector('#fees tbody');
const fields = ['fee_id', 'card_scheme', 'transactions', 'amount_eur', 'fee_eur'];
[...new Set(data.map(row => row.card_scheme))].sort().forEach(scheme => {
  const option = document.createElement('option');
  option.value = scheme;
  option.textContent = scheme;
  filter.appendChild(option);
});
function render() {
  const visible = data.filter(row => filter.value === '' || row.card_scheme === filter.value);
  const fragment = document.createDocumentFragment();
  visible.forEach(row => {
    const tr = document.createElement('tr');
    fields.forEach(field => {
      const td = document.createElement('td');
      td.textContent = String(row[field]);
      tr.appendChild(td);
    });
    fragment.appendChild(tr);
  });
  body.replaceChildren(fragment);
  document.getElementById('row-count').textContent = String(visible.length);
}
filter.addEventListener('change', render);
render();
</script>
</main></body></html>
'''.replace('__METHOD__',escape(method)).replace('__DATA__',data)
html_path.write_text(page,encoding='utf-8')
result={'answer':'ready','method':method,'sources':['/work/manual.md','/work/merchant_data.json','/work/payments.csv','/work/payments-readme.md','/work/fees.json'],'artifacts':{'csv':str(csv_path),'html':str(html_path)}}
result_path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'rows':len(audit),'transactions':len(month),'volume':str(volume),'fraud':str(fraud),'schemes':sorted(set(r['card_scheme'] for r in audit)),'result_path':str(result_path)},ensure_ascii=False))
