import csv,json
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

merchant='Belles_cookbook_store'
fees=json.load(open('/work/fees.json'))
profile=next(m for m in json.load(open('/work/merchant_data.json')) if m['merchant']==merchant)
with open('/work/payments.csv',newline='') as f:
    month=[r for r in csv.DictReader(f) if r['merchant']==merchant and int(r['year'])==2023 and 1<=int(r['day_of_year'])<=31]
volume=sum((Decimal(r['eur_amount']) for r in month),Decimal(0))
fraud=sum((Decimal(r['eur_amount']) for r in month if r['has_fraudulent_dispute']=='True'),Decimal(0))
fraud_pct=100*Fraction(fraud)/Fraction(volume)
day=[r for r in month if int(r['day_of_year'])==10]

def number(s):
    s=s.replace('%','')
    multiplier=1
    if s[-1:] in ('k','m'):
        multiplier={'k':1000,'m':1000000}[s[-1]]
        s=s[:-1]
    return Fraction(Decimal(s))*multiplier

def in_range(value,restriction):
    if restriction is None:return True
    if restriction.startswith('<'):return value<number(restriction[1:])
    if restriction.startswith('>'):return value>number(restriction[1:])
    low,high=restriction.split('-')
    return number(low)<=value<=number(high)

def category(value,restriction):
    return restriction is None or restriction==[] or (value in restriction if isinstance(restriction,list) else value==restriction)

def capture(restriction):
    if restriction is None:return True
    value=profile['capture_delay']
    if restriction in ('manual','immediate'):return value==restriction
    return value not in ('manual','immediate') and in_range(Fraction(value),restriction)

candidates=[r for r in fees if category(profile['account_type'],r['account_type']) and category(profile['merchant_category_code'],r['merchant_category_code']) and capture(r['capture_delay']) and in_range(Fraction(volume),r['monthly_volume']) and in_range(fraud_pct,r['monthly_fraud_level'])]
matched={}
for rule in candidates:
    rows=[p for p in day if category(p['card_scheme'],rule['card_scheme']) and category(p['is_credit']=='True',rule['is_credit']) and category(p['aci'],rule['aci']) and category(p['issuing_country']==p['acquirer_country'],rule['intracountry'])]
    if rows:matched[rule['ID']]=len(rows)
answer=','.join(map(str,sorted(matched)))
result={'answer':answer,'method':f'以当前 manual.md 的规则解释为准，空列表及 null 不限制，保留全部交易行。筛选该商户 2023 年 1 月全部交易，用输入十进制金额精确求和：月交易额 {volume} 欧元，欺诈争议金额 {fraud} 欧元；月欺诈百分比按 100×欺诈金额/月交易额以有理数精确比较。商户 account_type=R、merchant_category_code=5942、capture_delay=1（符合 <3）。将商户及月度限制与 2023-01-10 每笔交易的卡组织、信用卡标志、ACI、发卡国与收单国是否相同逐项匹配，取至少匹配一笔交易的全部规则 ID 并按数值排序。当日交易 {len(day)} 笔，适用规则 {len(matched)} 条。','sources':['/work/manual.md','/work/merchant_data.json','/work/payments.csv','/work/payments-readme.md','/work/fees.json']}
path=Path('/scratch/results/0-day.json')
path.parent.mkdir(parents=True,exist_ok=True)
if path.exists():
    i=1
    while path.with_name(f'0-day.previous-{i}.json').exists():i+=1
    path.with_name(f'0-day.previous-{i}.json').write_bytes(path.read_bytes())
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':result,'month_rows':len(month),'fraud_pct':float(fraud_pct),'match_counts':matched},ensure_ascii=False,indent=2))
