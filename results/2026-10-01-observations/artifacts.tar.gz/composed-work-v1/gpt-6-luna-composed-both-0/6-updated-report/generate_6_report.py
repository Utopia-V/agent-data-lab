import csv, json, html
from decimal import Decimal
from pathlib import Path

OUT = Path('/scratch/reports')
OUT.mkdir(parents=True, exist_ok=True)
MERCHANT = 'Belles_cookbook_store'
merchant = next(x for x in json.load(open('/work/merchant_data.json')) if x['merchant'] == MERCHANT)
with open('/work/payments.csv', newline='', encoding='utf-8') as f:
    payments = list(csv.DictReader(f))
jan_all = [r for r in payments if r['merchant'] == MERCHANT and r['year'] == '2023' and 1 <= int(r['day_of_year']) <= 31]
volume = sum((Decimal(r['eur_amount']) for r in jan_all), Decimal(0))
fraud_amount = sum((Decimal(r['eur_amount']) for r in jan_all if r['has_fraudulent_dispute'] == 'True'), Decimal(0))
fraud_pct = Decimal(100) * fraud_amount / volume if volume else Decimal(0)
fees = json.load(open('/work/fees.json'))

def restriction_applies(value, candidate):
    return value is None or value == [] or candidate in value

def capture_applies(rule_value):
    if rule_value is None:
        return True
    d = merchant['capture_delay']
    if rule_value == '<3':
        return d in ('immediate', '1', '2')
    if rule_value == '3-5':
        return d in ('3', '4', '5')
    if rule_value == '>5':
        return d.isdigit() and int(d) > 5
    return d == rule_value

def threshold_applies(value, metric):
    if value is None:
        return True
    if metric == 'volume':
        bounds = {
            '<100k': (None, Decimal(100000)),
            '100k-1m': (Decimal(100000), Decimal(1000000)),
            '1m-5m': (Decimal(1000000), Decimal(5000000)),
            '>5m': (Decimal(5000000), None),
        }
        val = volume
    else:
        bounds = {
            '<7.2%': (None, Decimal('7.2')),
            '7.2%-7.7%': (Decimal('7.2'), Decimal('7.7')),
            '7.7%-8.3%': (Decimal('7.7'), Decimal('8.3')),
            '>8.3%': (Decimal('8.3'), None),
        }
        val = fraud_pct
    lo, hi = bounds[value]
    return (lo is None or val >= lo) and (hi is None or val < hi)

rows = []
for rule in fees:
    if not restriction_applies(rule['account_type'], merchant['account_type']):
        continue
    if not restriction_applies(rule['merchant_category_code'], merchant['merchant_category_code']):
        continue
    if not capture_applies(rule['capture_delay']):
        continue
    if not threshold_applies(rule['monthly_volume'], 'volume') or not threshold_applies(rule['monthly_fraud_level'], 'fraud'):
        continue
    matched = []
    for p in jan_all:
        if p['card_scheme'] != rule['card_scheme']:
            continue
        if rule['is_credit'] is not None and (p['is_credit'] == 'True') != rule['is_credit']:
            continue
        if not restriction_applies(rule['aci'], p['aci']):
            continue
        is_domestic = p['issuing_country'] == p['acquirer_country']
        if rule['intracountry'] is not None and is_domestic != bool(rule['intracountry']):
            continue
        matched.append(p)
    if not matched:
        continue
    amount = sum((Decimal(p['eur_amount']) for p in matched), Decimal(0))
    fixed = Decimal(str(rule['fixed_amount']))
    rate = Decimal(str(rule['rate']))
    fee = sum((fixed + rate * Decimal(p['eur_amount']) / Decimal(10000) for p in matched), Decimal(0))
    rows.append({
        'fee_id': int(rule['ID']),
        'card_scheme': rule['card_scheme'],
        'transactions': len(matched),
        'amount_eur': f'{amount:.2f}',
        'fee_eur': f'{fee:.6f}',
    })
rows.sort(key=lambda x: x['fee_id'])

csv_path = OUT / '6.csv'
with open(csv_path, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['fee_id', 'card_scheme', 'transactions', 'amount_eur', 'fee_eur'])
    writer.writeheader()
    writer.writerows(rows)

schemes = sorted({r['card_scheme'] for r in rows})
options = ''.join(f'<option value="{html.escape(s, quote=True)}">{html.escape(s)}</option>' for s in schemes)
data_json = json.dumps(rows, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
page = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Belles_cookbook_store — January 2023 fee audit</title>
<style>
:root { color-scheme: light; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; color: #172033; background: #f5f7fb; }
body { margin: 0; padding: 2rem; }
main { max-width: 1100px; margin: 0 auto; background: #fff; padding: 1.5rem 1.75rem; border: 1px solid #dce2ec; border-radius: 12px; box-shadow: 0 4px 18px #18294a12; }
h1 { margin: 0 0 .35rem; font-size: 1.45rem; }
p { margin: .25rem 0 1.2rem; color: #4d5b71; }
label { font-weight: 600; }
select { margin-left: .5rem; padding: .45rem .65rem; border: 1px solid #aeb9ca; border-radius: 6px; background: white; font: inherit; }
#row-count { margin: 1rem 0 .5rem; color: #46546a; font-size: .92rem; }
.table-wrap { overflow-x: auto; }
table { border-collapse: collapse; width: 100%; font-variant-numeric: tabular-nums; }
th, td { padding: .65rem .75rem; border-bottom: 1px solid #e4e8ef; text-align: left; }
th { background: #eef2f8; color: #26344b; }
td.num, th.num { text-align: right; }
tbody tr:hover { background: #f7f9fc; }
@media (max-width: 600px) { body { padding: .75rem; } main { padding: 1rem; } }
</style>
</head>
<body>
<main>
<h1>逐规则费用审计</h1>
<p>Belles_cookbook_store · 2023年1月。每条规则独立计算；重叠规则不合并为单张账单。</p>
<label for="scheme-filter">Card scheme</label><select id="scheme-filter"><option value="">All schemes</option>'''+options+'''</select>
<div id="row-count" aria-live="polite"></div>
<div class="table-wrap"><table id="fees">
<thead><tr><th>fee_id</th><th>card_scheme</th><th class="num">transactions</th><th class="num">amount_eur</th><th class="num">fee_eur</th></tr></thead>
<tbody></tbody>
</table></div>
</main>
<script id="fee-data" type="application/json">'''+data_json+'''</script>
<script>
(() => {
  const data = JSON.parse(document.getElementById('fee-data').textContent);
  const filter = document.getElementById('scheme-filter');
  const body = document.querySelector('#fees tbody');
  const count = document.getElementById('row-count');
  function render() {
    const selected = filter.value;
    const visible = data.filter(row => !selected || row.card_scheme === selected);
    body.replaceChildren(...visible.map(row => {
      const tr = document.createElement('tr');
      for (const [key, cls] of [['fee_id',''], ['card_scheme',''], ['transactions','num'], ['amount_eur','num'], ['fee_eur','num']]) {
        const td = document.createElement('td');
        td.textContent = row[key];
        if (cls) td.className = cls;
        tr.appendChild(td);
      }
      return tr;
    }));
    count.textContent = `${visible.length} rows`;
  }
  filter.addEventListener('change', render);
  render();
})();
</script>
</body>
</html>
'''
html_path = OUT / '6.html'
html_path.write_text(page, encoding='utf-8')
result = {
  'answer': 'ready',
  'method': 'Recomputed the January 2023 merchant-month volume and fraudulent-dispute percentage, matched each fee rule against merchant and transaction restrictions, and independently summed matching transaction amounts and per-transaction fees using Decimal arithmetic. Overlapping rules remain separate audit rows; the HTML embeds the same formatted table data as the CSV.',
  'sources': ['/work/payments.csv', '/work/merchant_data.json', '/work/fees.json', '/work/manual.md'],
  'artifacts': {'csv': str(csv_path), 'html': str(html_path)}
}
Path('/scratch/results').mkdir(parents=True, exist_ok=True)
Path('/scratch/results/6-updated-report.json').write_text(json.dumps(result, ensure_ascii=False), encoding='utf-8')
print(json.dumps({'rows': len(rows), 'month_transactions': len(jan_all), 'month_volume_eur': str(volume), 'month_fraud_pct': str(fraud_pct), 'schemes': schemes, 'csv': str(csv_path), 'html': str(html_path), 'result': result}, ensure_ascii=False))
