import csv,json,decimal
from decimal import Decimal
merchant='Rafa_AI'; year='2023';
meta=next(m for m in json.load(open('/work/merchant_data.json')) if m['merchant']==merchant)
with open('/work/payments.csv') as f:
    allm=[r for r in csv.DictReader(f) if r['merchant']==merchant and r['year']==year and 1<=int(r['day_of_year'])<=31]
vol=sum((Decimal(r['eur_amount']) for r in allm),Decimal(0))
fraud=sum((Decimal(r['eur_amount']) for r in allm if r['has_fraudulent_dispute']=='True'),Decimal(0))
pct=100*fraud/vol

def in_range(v,s):
    if s is None: return True
    if s=='<100k': return v<100000
    if s=='100k-1m': return 100000<=v<=1000000
    if s=='1m-5m': return 1000000<=v<=5000000
    if s=='>5m': return v>5000000
    if s=='<7.2%': return pct<Decimal('7.2')
    if s=='7.2%-7.7%': return Decimal('7.2')<=pct<=Decimal('7.7')
    if s=='7.7%-8.3%': return Decimal('7.7')<=pct<=Decimal('8.3')
    if s=='>8.3%': return pct>Decimal('8.3')
    raise ValueError(s)

def match(rule,r):
    # null and empty lists do not restrict
    for field, val in [('card_scheme',r['card_scheme'])]:
        if rule[field] is not None and rule[field]!=val:return False
    for field,val in [('account_type',meta['account_type']),('merchant_category_code',meta['merchant_category_code']),('aci',r['aci'])]:
        allowed=rule[field]
        if allowed and val not in allowed:return False
    if rule['capture_delay'] is not None:
        rd=rule['capture_delay']; delay=meta['capture_delay']
        if rd=='<3' and not (Decimal(delay)<3): return False
        if rd=='3-5' and not (3<=Decimal(delay)<=5): return False
        if rd=='>5' and not (Decimal(delay)>5): return False
        if rd in ('immediate','manual') and delay!=rd:return False
    if not in_range(pct,rule['monthly_fraud_level']) or not in_range(vol,rule['monthly_volume']):return False
    if rule['is_credit'] is not None and (r['is_credit']=='True')!=rule['is_credit']:return False
    if rule['intracountry'] is not None and (r['issuing_country']==r['acquirer_country'])!=bool(rule['intracountry']): return False
    return True
rules=json.load(open('/work/fees.json'))
matched=sorted({rule['ID'] for rule in rules if any(match(rule,r) for r in allm)})
print('volume',vol,'fraud',fraud,'pct',pct,'merchant',meta)
print('matching count',len(matched));print(','.join(map(str,matched)))
