import csv, json
from decimal import Decimal
from html import escape
from pathlib import Path

ROOT = Path('/work')
OUT = Path('/scratch/reports')
merchant_name = 'Belles_cookbook_store'
with open(ROOT / 'merchant_data.json', encoding='utf-8') as f:
    merchants = json.load(f)
merchant = next(x for x in merchants if x['merchant'] == merchant_name)
with open(ROOT / 'fees.json', encoding='utf-8') as f:
    rules = json.load(f)
with open(ROOT / 'payments.csv', encoding='utf-8', newline='') as f:
    payments = [r for r in csv.DictReader(f) if r['merchant'] == merchant_name and r['year'] == '2023' and 1 <= int(r['day_of_year']) <= 31]

# Natural-month volume/fraud metrics use all January transactions, not only transactions ultimately matched by a given rule.
monthly_volume = sum((Decimal(r['eur_amount']) for r in payments), Decimal(0))
monthly_fraud_amount = sum((Decimal(r['eur_amount']) for r in payments if r['has_fraudulent_dispute'] == 'True'), Decimal(0))
monthly_fraud_pct = Decimal(100) * monthly_fraud_amount / monthly_volume if monthly_volume else Decimal(0)

def matches_month_range(value, constraint):
    if constraint is None:
        return True
    if constraint == '<100k': return value < Decimal(100000)
    if constraint == '100k-1m': return Decimal(100000) <= value <= Decimal(1000000)
    if constraint == '1m-5m': return Decimal(1000000) <= value <= Decimal(5000000)
    if constraint == '>5m': return value > Decimal(5000000)
    if constraint == '<7.2%': return monthly_fraud_pct < Decimal('7.2')
    if constraint == '7.2%-7.7%': return Decimal('7.2') <= monthly_fraud_pct <= Decimal('7.7')
    if constraint == '7.7%-8.3%': return Decimal('7.7') <= monthly_fraud_pct <= Decimal('8.3')
    if constraint == '>8.3%': return monthly_fraud_pct > Decimal('8.3')
    raise ValueError(f'Unknown range: {constraint}')

def matches_capture(rule_delay):
    if rule_delay is None: return True
    merchant_delay = merchant['capture_delay']
    if rule_delay in ('immediate', 'manual'):
        return merchant_delay == rule_delay
    days = Decimal(merchant_delay)
    if rule_delay == '<3': return days < 3
    if rule_delay == '3-5': return Decimal(3) <= days <= Decimal(5)
    if rule_delay == '>5': return days > 5
    raise ValueError(f'Unknown capture delay: {rule_delay}')

def rule_matches(rule, tx):
    if rule['card_scheme'] != tx['card_scheme']:
        return False
    for key, value in (('account_type', merchant['account_type']), ('merchant_category_code', merchant['merchant_category_code']), ('aci', tx['aci'])):
        restriction = rule[key]
        if restriction and value not in restriction: # empty lists impose no restriction
            return False
    if not matches_capture(rule['capture_delay']):
        return False
    if not matches_month_range(monthly_volume, rule['monthly_volume']):
        return False
    if not matches_month_range(monthly_fraud_pct, rule['monthly_fraud_level']):
        return False
    if rule['is_credit'] is not None and (tx['is_credit'] == 'True') != rule['is_credit']:
        return False
    if rule['intracountry'] is not None and (tx['issuing_country'] == tx['acquirer_country']) != bool(rule['intracountry']):
        return False
    return True

aggregated = {}
for rule in rules:
    matches = [tx for tx in payments if rule_matches(rule, tx)]
    if not matches:
        continue
    amount = sum((Decimal(tx['eur_amount']) for tx in matches), Decimal(0))
    fee = sum((Decimal(str(rule['fixed_amount'])) + Decimal(rule['rate']) * Decimal(tx['eur_amount']) / Decimal(10000) for tx in matches), Decimal(0))
    aggregated[rule['ID']] = {
        'fee_id': rule['ID'],
        'card_scheme': rule['card_scheme'],
        'transactions': len(matches),
        'amount_eur': amount,
        'fee_eur': fee,
    }
rows = [aggregated[key] for key in sorted(aggregated)]

csv_path = OUT / '5.csv'
with open(csv_path, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['fee_id', 'card_scheme', 'transactions', 'amount_eur', 'fee_eur'])
    writer.writeheader()
    for row in rows:
        writer.writerow({
            'fee_id': row['fee_id'],
            'card_scheme': row['card_scheme'],
            'transactions': row['transactions'],
            'amount_eur': f"{row['amount_eur']:.2f}",
            'fee_eur': f"{row['fee_eur']:.6f}",
        })

schemes = sorted({row['card_scheme'] for row in rows})
data = [{
    'fee_id': row['fee_id'],
    'card_scheme': row['card_scheme'],
    'transactions': row['transactions'],
    'amount_eur': f"{row['amount_eur']:.2f}",
    'fee_eur': f"{row['fee_eur']:.6f}",
} for row in rows]
data_json = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
options = ''.join(f'<option value="{escape(s, quote=True)}">{escape(s)}</option>' for s in schemes)
html_doc = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>January 2023 Fee Audit — Belles_cookbook_store</title>
<style>
:root {{ color-scheme: light; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; color: #17212b; background: #f4f7fa; }}
body {{ margin: 0; padding: 2rem; }}
main {{ max-width: 1100px; margin: 0 auto; background: white; padding: 1.75rem; border: 1px solid #d8e0e8; border-radius: 12px; box-shadow: 0 8px 28px #14283a12; }}
h1 {{ font-size: 1.55rem; margin: 0 0 .4rem; }}
p {{ color: #475569; margin: .3rem 0 1.3rem; }}
label {{ font-weight: 650; margin-right: .6rem; }}
select {{ font: inherit; padding: .45rem .7rem; border: 1px solid #aebbc8; border-radius: 6px; background: white; }}
#row-count {{ margin: 1rem 0 .55rem; font-size: .95rem; color: #334155; }}
.table-wrap {{ overflow-x: auto; }}
table {{ width: 100%; border-collapse: collapse; font-variant-numeric: tabular-nums; }}
th, td {{ padding: .7rem .75rem; border-bottom: 1px solid #e2e8f0; text-align: left; white-space: nowrap; }}
th {{ background: #edf3f8; color: #26384a; }}
td.num {{ text-align: right; }}
tbody tr:hover {{ background: #f7fafc; }}
</style>
</head>
<body>
<main>
<h1>January 2023 per-rule fee audit</h1>
<p>Merchant: Belles_cookbook_store. Each rule is audited independently; overlapping rules are not combined into an invoice total.</p>
<label for="scheme-filter">Card scheme</label>
<select id="scheme-filter"><option value="">All schemes</option>{options}</select>
<div id="row-count" aria-live="polite"></div>
<div class="table-wrap"><table id="fees">
<thead><tr><th scope="col">fee_id</th><th scope="col">card_scheme</th><th scope="col">transactions</th><th scope="col">amount_eur</th><th scope="col">fee_eur</th></tr></thead>
<tbody></tbody>
</table></div>
</main>
<script id="fee-data" type="application/json">{data_json}</script>
<script>
(() => {{
  const data = JSON.parse(document.getElementById('fee-data').textContent);
  const filter = document.getElementById('scheme-filter');
  const tbody = document.querySelector('#fees tbody');
  const count = document.getElementById('row-count');
  function render() {{
    const selected = filter.value;
    const visible = data.filter(row => !selected || row.card_scheme === selected);
    tbody.replaceChildren(...visible.map(row => {{
      const tr = document.createElement('tr');
      for (const key of ['fee_id', 'card_scheme', 'transactions', 'amount_eur', 'fee_eur']) {{
        const td = document.createElement('td');
        td.textContent = String(row[key]);
        if (['transactions', 'amount_eur', 'fee_eur'].includes(key)) td.className = 'num';
        tr.appendChild(td);
      }}
      return tr;
    }}));
    count.textContent = `${{visible.length}} rules`;
  }}
  filter.addEventListener('change', render);
  render();
}})();
</script>
</body>
</html>
'''
html_path = OUT / '5.html'
html_path.write_text(html_doc, encoding='utf-8')

result = {
    'answer': 'ready',
    'method': '筛选 Belles_cookbook_store 2023 年 1 月交易；依照 manual.md 使用全月交易计算月交易量和欺诈率，并将费用规则的商户限制与每笔交易限制逐一匹配。逐规则汇总匹配笔数、交易金额，以及按 fixed_amount + rate × eur_amount / 10000 计算的费用；每条规则独立统计，不将重叠规则合并。CSV 与 HTML 表格数据由同一计算结果生成。',
    'sources': ['/work/manual.md', '/work/merchant_data.json', '/work/fees.json', '/work/payments.csv'],
    'artifacts': {'csv': str(csv_path), 'html': str(html_path)},
}
result_path = Path('/scratch/results/5-report.json')
result_path.write_text(json.dumps(result, ensure_ascii=False), encoding='utf-8')
print('merchant_meta=', json.dumps(merchant, ensure_ascii=False))
print('transaction_count=', len(payments), 'monthly_volume=', monthly_volume, 'monthly_fraud_amount=', monthly_fraud_amount, 'monthly_fraud_pct=', monthly_fraud_pct)
print('audit_rows=', len(rows), 'schemes=', schemes)
print('csv=', csv_path, 'html=', html_path, 'result=', result_path)
print(csv_path.read_text())
