import csv
import json
from decimal import Decimal
from pathlib import Path

ROOT = Path('/work')
amount = Decimal('10')
account_type = 'H'
category_name = 'Eating Places and Restaurants'
scheme = 'GlobalCard'

# Resolve the specified merchant category from the current category source.
with (ROOT / 'merchant_category_codes.csv').open(newline='', encoding='utf-8') as f:
    categories = list(csv.reader(f))
mccs = {int(row[1]) for row in categories if len(row) >= 3 and row[2] == category_name}
if len(mccs) != 1:
    raise ValueError(f'Expected one MCC for {category_name!r}; found {sorted(mccs)}')
mcc = next(iter(mccs))

rules = json.loads((ROOT / 'fees.json').read_text(encoding='utf-8'))
# Apply only the specified dimensions. A null list field means all values per manual.md;
# other characteristics (credit, ACI, capture, volume, fraud, geography) are not filtered.
def matches(rule):
    accounts = rule['account_type']
    codes = rule['merchant_category_code']
    return (rule['card_scheme'] == scheme
            and (accounts is None or account_type in accounts)
            and (codes is None or mcc in codes))

selected = [rule for rule in rules if matches(rule)]
if not selected:
    raise ValueError('No matching fee rules')
fees = [Decimal(str(r['fixed_amount'])) + Decimal(str(r['rate'])) * amount / Decimal(10000) for r in selected]
mean = sum(fees, Decimal(0)) / len(fees)
answer = {
    'answer': f'EUR {mean:.6f}',
    'method': (f"Mapped {category_name} to MCC {mcc} using merchant_category_codes.csv. "
               f"Selected {len(selected)} GlobalCard rules whose account_type includes H (or is null) "
               f"and whose merchant_category_code includes {mcc} (or is null); no other rule dimensions "
               f"were filtered. For each rule calculated fixed_amount + rate × EUR 10 / 10000, "
               f"then averaged equally: {', '.join(f'EUR {x:.6f}' for x in fees)} -> EUR {mean:.6f}."),
    'sources': ['fees.json', 'merchant_category_codes.csv', 'manual.md']
}
(ROOT.parent / 'scratch' / 'answer.json').write_text(json.dumps(answer, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'mcc': mcc, 'rule_ids': [r['ID'] for r in selected], 'fees': [str(x) for x in fees], 'mean': str(mean), 'answer': answer}, ensure_ascii=False, indent=2))
