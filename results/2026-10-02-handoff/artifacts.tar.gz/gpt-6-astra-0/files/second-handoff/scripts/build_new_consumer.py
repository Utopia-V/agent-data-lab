#!/usr/bin/env python3
"""Derive consumer answers from current source, preserving earlier deliveries."""
import json
from pathlib import Path
from extract_resource_policy import extract, unique
from extract_content_methods import fields, pair

root = Path('/work/project')
policy = extract(root)
source = (root / 'packages/repa/src/content/resources.ts').read_text()
get_body = source.split('  get(host: string, id: string): ResourceHold {', 1)[1].split('  renew(', 1)[0]
assert 'lease.hold.expiresAt <= this.#now() && !this.#activeHosts.has(host)' in get_body
assert 'throw new RepaFault("lease_expired"' in get_body
schema = (root / 'packages/repa/src/configuration/schema.ts').read_text().replace('\n', ' ')
query = dict(pair(f) for f in fields(unique(r'const query = (\{.*?\});', schema)))
body = unique(r'export const SettingsResetParamsSchema = object\((\{.*?\})\);', schema)
params = {}
for field in fields(body):
    if field == '...query':
        params.update(query)
    else:
        key, value = pair(field)
        params[key] = value
result = {
    'upload_24_mib_allowed': 24 * 1024 * 1024 <= policy['upload_limit_bytes'],
    'upload_48_mib_allowed': 48 * 1024 * 1024 <= policy['upload_limit_bytes'],
    'inactive_hold_after_40_minutes': 'lease_expired' if 40 * 60 * 1000 >= policy['hold_ms'] else 'available',
    'settings_reset_required': [key for key, value in params.items() if not value.startswith('Type.Optional(')],
}
output = Path('/scratch/answers/new-consumer.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
