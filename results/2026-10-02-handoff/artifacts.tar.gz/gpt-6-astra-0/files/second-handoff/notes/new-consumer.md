# 前端资源使用判定

结果：`/scratch/answers/new-consumer.json`。复现：`python3 /scratch/scripts/build_new_consumer.py`。

接续 handoff-package.json 与 changed-policy.json，并核对当前源码；resource-policy.json 的 64 MiB 和 60 分钟属于历史默认值，保留但不采用。

当前 server.ts 上传分支按请求累计字节数判断 `size > 32 * 1024 * 1024` 时返回 413。24 MiB 为 25165824 字节，在上限内；48 MiB 为 50331648 字节，超出上限。

content/resources.ts 默认 hold 期限为 30 分钟。未续期且宿主不活跃时，get 在 expiresAt 不晚于当前时间的条件下返回 lease_expired；40 分钟满足此条件。未显式关闭不免除超时判定，资源仍存在也不免除租约检查。application.ts 的 detach 会清除活跃状态，只有 confirmed 为真时另行 releaseHost。

configuration/schema.ts 中 SettingsResetParamsSchema 展开 query 后，必填顶层字段是 scope、namespace、key、base；没有 value 或 operationId。protocol.ts 将 settings.reset 注册到该 schema。

以上为当前固定源码判读与提取，不是运行 TypeScript 集成测试。生成过程不重写此前答案或脚本。
