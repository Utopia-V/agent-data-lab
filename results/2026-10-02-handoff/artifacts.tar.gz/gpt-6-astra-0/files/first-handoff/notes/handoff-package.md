# 当前接入交付包

JSON：`/scratch/answers/handoff-package.json`。
CSV：`/scratch/delivery.csv`。
生成与校验程序：`/scratch/scripts/build_handoff_package.py`。

四个分区分别采用 client-validation.json、integration-plan.json、changed-policy.json、prompt-settings.json。资源策略使用更新后的 changed-policy.json，保留全部 cases；旧 resource-policy.json 仅作为历史结果保留，不纳入当前交付。

CSV 使用 section,key,value 表头，每个分区的直接字段一行，共 19 行数据。数组和 cases 对象保持为单个 JSON 值，字符串、数字和布尔值也按 JSON 编码。通过 CSV 解析器读取后，对 value 进行 JSON 解析，即可还原交付 JSON。

已校验 CSV 还原值与 JSON 完全一致，资源默认值与当前实现一致（hold 为 1800000 ms，上传上限为 33554432 字节），并确认所有已有历史答案的内容哈希未变。
