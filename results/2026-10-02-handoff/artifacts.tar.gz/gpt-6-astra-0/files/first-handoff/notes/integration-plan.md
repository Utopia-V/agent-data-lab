# 网页接入依赖清单依据

结果：`/scratch/answers/integration-plan.json`。生成程序：`/scratch/scripts/extract_integration_plan.py`。

- `/work/issues/23.json`：标题确认交互产物桥接归属 #23；只提取“依赖与协作”段的直接依赖，按出现顺序为 #17、#20、#21、#10。不把正文其他位置的实施入口、契约、消费者编号加入依赖清单。
- `/work/project/packages/repa/src/agent/tools.ts`：createContentTools 最终返回 `[read, edit, write, patch]`。前三个继承 Pi 工具定义名称，patch 明确声明 name 为 apply_patch；`docs/development/agent-runtime.md` 的“内容工具与复用边界”及 `packages/repa/test/agent-tools.test.ts` 的按名称调用与这些名称一致。这里列函数返回的模型工具，不列公开内容协议方法或设计中的命令工具。
- `/work/project/packages/repa/src/protocol.ts`：公开 methods 展开 contentMethods、spaceMethods；运行方法仅登记 run.submit、run.get、run.cancel，没有 run.steer。`docs/development/agent-runtime.md` 也明确 Pi 的 steer 尚未接通 Repa 公开接口和 Host。
- `/work/project/packages/repa/src/content/protocol.ts`：contentMethods 已登记 resource.hold，且纳入总协议。
- `/work/project/docs/development/resources.md`：hostKey 与后端主令牌只交给完整前端宿主，生成页面不直接取得完整客户端。`docs/adr/0005-execute-display-content-with-host-permissions.md` 的“展示内容与交互”要求实例只取得获准数据、资源和动作，不取得完整客户端或主连接令牌；因此页面不得取得完整 hostKey。

本次按冻结实现和设计分别判断，没有把 Issue 的交付要求当作当前已实现接口，也未运行项目测试。
