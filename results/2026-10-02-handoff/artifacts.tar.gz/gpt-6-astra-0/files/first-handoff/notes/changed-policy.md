# 更新后的客户端资源策略

结果：`/scratch/answers/changed-policy.json`。复现：`python3 /scratch/scripts/extract_changed_policy.py`。

沿用 `extract_resource_policy.py` 读取当前实现，不覆盖历史 `resource-policy.json` 及其说明。旧结果对应旧来源，不能作为当前默认值。

当前来源：`/work/project/packages/repa/src/content/resources.ts` 与 `/work/project/packages/repa/src/server.ts`。preparation 默认 10 分钟（600000 ms）；hold 默认已改为 30 分钟（1800000 ms）；上传上限已改为 32 × 1024 × 1024 字节（33554432），超过上限返回 HTTP 413。资源下载仍使用 application/octet-stream 和 attachment。开发文档未同步，不用于覆盖实现。

四个场景根据 ResourceRetention 的实际分支判断，忽略题目未指定的资源缺失等故障：

- 未续期且宿主失联，45 分钟超过 30 分钟默认期限；get 的过期且非活跃条件成立，返回 lease_expired。
- 宿主仍标记为活跃时，get 的时间过期分支不成立；即使未续期且 expiresAt 已过，仍返回持有记录，记为 available。
- release 把记录 kind 改为 released；renew 对非 hold 记录直接返回 lease_expired，不会重新启用。
- get 先检查宿主归属；另一宿主读取仍有效的 hold 返回 permission_required。

上述为源码分支推导，不是重新执行项目测试的结果。生成脚本检查对应条件仍存在，并保留旧策略输出。
