# 客户端参数检查清单

结果：`/scratch/answers/client-validation.json`。
复用 `extract_content_methods.py` 的声明提取逻辑，由 `extract_client_validation.py` 直接读取当前源码并筛选。历史清单和脚本保持不变。

范围为 `/work/project/packages/repa/src/content/protocol.ts` 的 `contentMethods` 全部 25 个已登记方法，展开 params 顶层对象别名和 spread，不展开嵌套字段，不读取 result。

`operation_without_base`：required 中包含 operationId 且不包含 base，共 6 个。
`requires_base`：required 中包含 base，共 8 个。

按注册顺序保留方法名，不依据方法命名或读写性质判断。operation.get、operation.undo、operation.reconcile 均符合第一组；operation.prune 的 operationIds 不是 operationId。

声明依据：protocol.ts 的 operation 别名、各方法 params；../schema.ts 的 object、IdSchema、RevisionSchema；content/schema.ts 的 WriteBaseSchema。WriteBaseSchema 不是 Optional，content.write.base 必填。

复现：`python3 /scratch/scripts/extract_client_validation.py`。
