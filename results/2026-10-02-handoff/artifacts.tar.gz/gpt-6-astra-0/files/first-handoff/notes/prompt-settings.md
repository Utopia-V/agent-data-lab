# 提示配置编辑器参数

结果：`/scratch/answers/prompt-settings.json`。
复现：`python3 /scratch/scripts/extract_prompt_settings.py`。

`/work/project/packages/repa/src/protocol.ts` 将 settings.set 和 settings.reset 分别绑定到 SettingsSetParamsSchema 和 SettingsResetParamsSchema；不使用 contentMethods 清单推断此模块。

`/work/project/packages/repa/src/configuration/schema.ts` 中，query 提供 scope、namespace，set 另声明 key、value、base，reset 另声明 key、base。这些顶层字段均无 Type.Optional 标记；value 的 Type.Unknown() 也不是 Optional。reset 未声明 operationId。

SettingScopeSchema 的 kind 只有 application、space、session。SettingsEntrySchema.source 中另有 default 字面量，但它不是设置作用域的 kind。scope 内部的 spaceId、sessionId 不计入方法顶层参数。

PromptSettingsSchema.fileChanges 使用 literals 声明 on-demand、notice、diff 三种模式。`../schema.ts` 的 object 直接构造 Type.Object，literals 直接构造 Type.Enum，不额外改变必填性或枚举值。
