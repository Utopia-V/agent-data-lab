#!/usr/bin/env python3
"""Generate integration facts from the frozen issue, registry and reviewed design."""
import json
import re
from pathlib import Path
from extract_content_methods import extract

root = Path('/work/project')
issue = json.loads(Path('/work/issues/23.json').read_text())
assert '交互产物展示与受限桥接' in issue['title']
section = issue['body'].split('## 依赖与协作', 1)[1].split('\n## ', 1)[0]
dependencies = list(dict.fromkeys(map(int, re.findall(r'#(\d+)', section))))
tools_source = (root / 'packages/repa/src/agent/tools.ts').read_text()
assert 'return [read, edit, write, patch];' in tools_source
assert 'name: "apply_patch"' in tools_source
runtime_doc = (root / 'docs/development/agent-runtime.md').read_text()
model_tools = ['read', 'edit', 'write', 'apply_patch']
assert all(f'| `{name}` |' in runtime_doc for name in model_tools)
protocol = (root / 'packages/repa/src/protocol.ts').read_text()
assert '...contentMethods,' in protocol and '...spaceMethods,' in protocol
# Read the root registry and the two registries it includes.
protocol_sources = [root / relative for relative in (
    "packages/repa/src/protocol.ts",
    "packages/repa/src/content/protocol.ts",
    "packages/repa/src/spaces/schema.ts",
)]
steer_registered = any(re.search(r'[\"\']run\.steer[\"\']\s*:', p.read_text()) for p in protocol_sources)
content_methods = extract((root / 'packages/repa/src/content/protocol.ts').read_text())['methods']
resources_doc = (root / 'docs/development/resources.md').read_text()
assert '`hostKey` 与后端主令牌只交给完整前端宿主' in resources_doc
result = {
    'display_bridge_issue': issue['number'],
    'display_dependencies': dependencies,
    'model_tools': model_tools,
    'public_run_steer_registered': steer_registered,
    'resource_hold_registered': any(m['method'] == 'resource.hold' for m in content_methods),
    'display_page_receives_host_key': False,
}
output = Path('/scratch/answers/integration-plan.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
