#!/usr/bin/env python3
"""Bundle current results and emit a JSON-valued CSV with round-trip validation."""
import csv
import hashlib
import json
from pathlib import Path
from extract_resource_policy import extract

scratch = Path('/scratch')
inputs = {
    'parameter_filters': 'client-validation.json',
    'integration': 'integration-plan.json',
    'resources': 'changed-policy.json',
    'settings': 'prompt-settings.json',
}
# Record every existing answer so packaging cannot silently rewrite prior results.
output = scratch / 'answers/handoff-package.json'
historical = {p: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (scratch / 'answers').glob('*.json') if p != output}
package = {section: json.loads((scratch / 'answers' / name).read_text())
           for section, name in inputs.items()}
current_resource_policy = extract(Path('/work/project'))
assert all(package['resources'][key] == value for key, value in current_resource_policy.items())
assert package['resources']['hold_ms'] == 1800000
assert package['resources']['upload_limit_bytes'] == 33554432
assert len(package['resources']['cases']) == 4
output.write_text(json.dumps(package, ensure_ascii=False, indent=2) + '\n')
csv_path = scratch / 'delivery.csv'
with csv_path.open('w', newline='', encoding='utf-8') as stream:
    writer = csv.writer(stream)
    writer.writerow(['section', 'key', 'value'])
    for section, fields in package.items():
        for key, value in fields.items():
            writer.writerow([section, key, json.dumps(value, ensure_ascii=False, separators=(',', ':'))])

reconstructed = {}
with csv_path.open(newline='', encoding='utf-8') as stream:
    reader = csv.DictReader(stream)
    assert reader.fieldnames == ['section', 'key', 'value']
    for row in reader:
        fields = reconstructed.setdefault(row['section'], {})
        assert row['key'] not in fields
        fields[row['key']] = json.loads(row['value'])
assert reconstructed == json.loads(output.read_text()) == package
assert all(hashlib.sha256(p.read_bytes()).hexdigest() == digest for p, digest in historical.items())
print(f'Validated {output} and {csv_path}: {sum(map(len, package.values()))} direct-field rows; historical answers unchanged.')
