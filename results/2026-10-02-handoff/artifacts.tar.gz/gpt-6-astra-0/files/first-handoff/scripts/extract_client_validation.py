#!/usr/bin/env python3
"""Filter registered contentMethods by required top-level parameter declarations."""
import json
from pathlib import Path
from extract_content_methods import extract

source = Path('/work/project/packages/repa/src/content/protocol.ts')
methods = extract(source.read_text())['methods']
result = {
    'operation_without_base': [m['method'] for m in methods
                               if 'operationId' in m['required'] and 'base' not in m['required']],
    'requires_base': [m['method'] for m in methods if 'base' in m['required']],
}
output = Path('/scratch/answers/client-validation.json')
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
