#!/usr/bin/env python3
"""Current resource defaults plus source-reviewed lease cases; preserve old outputs."""
import json
from pathlib import Path
from extract_resource_policy import extract

root = Path('/work/project')
result = extract(root)
source = (root / 'packages/repa/src/content/resources.ts').read_text()
# Guard the branch semantics used for the four requested scenarios.
assert 'lease.hold.expiresAt <= this.#now() && !this.#activeHosts.has(host)' in source
assert 'if (!lease || lease.kind !== "hold") throw new RepaFault("lease_expired"' in source
assert 'if (lease.host !== host) throw new RepaFault("permission_required"' in source
assert '...lease, kind: "released", hold:' in source
get_body = source.split('  get(host: string, id: string): ResourceHold {', 1)[1].split('  renew(', 1)[0]
assert get_body.index('this.#checkOwner(lease, host)') < get_body.index('lease.hold.expiresAt')
assert 'throw new RepaFault("lease_expired"' in get_body
elapsed_ms = 45 * 60 * 1000
result['cases'] = {
    'disconnected_after_45_minutes': 'lease_expired' if elapsed_ms >= result['hold_ms'] else 'available',
    'active_after_45_minutes': 'available',
    'renew_after_release': 'lease_expired',
    'another_host_get': 'permission_required',
}
output = Path('/scratch/answers/changed-policy.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
