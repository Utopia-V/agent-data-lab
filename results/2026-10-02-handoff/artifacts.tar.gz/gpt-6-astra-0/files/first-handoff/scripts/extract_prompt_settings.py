#!/usr/bin/env python3
"""Read settings parameter declarations, scope variants, and fileChanges modes."""
import json
import re
from pathlib import Path
from extract_content_methods import fields, pair
from extract_resource_policy import unique

root = Path('/work/project/packages/repa/src')
source = (root / 'configuration/schema.ts').read_text()
protocol = (root / 'protocol.ts').read_text()
for method, schema in [('set', 'SettingsSetParamsSchema'), ('reset', 'SettingsResetParamsSchema')]:
    assert f'"settings.{method}": method({schema}, SettingsViewSchema)' in protocol
query = dict(pair(field) for field in fields(unique(r'const query = (\{.*?\});', source.replace('\n', ' '))))

def required(schema):
    body = unique(r'export const ' + schema + r' = object\((\{.*?\})\);', source.replace('\n', ' '))
    params = {}
    for field in fields(body):
        if field == '...query':
            params.update(query)
        else:
            key, value = pair(field)
            params[key] = value
    return [key for key, value in params.items() if not value.startswith('Type.Optional(')]

scope = source.split('export const SettingScopeSchema = Type.Union([', 1)[1].split(']);', 1)[0]
modes = unique(r'fileChanges: literals\((\[[^\]]*\])\)', source)
result = {
    'set_required': required('SettingsSetParamsSchema'),
    'reset_required': required('SettingsResetParamsSchema'),
    'scope_kinds': re.findall(r'kind: Type.Literal\("([^"]+)"\)', scope),
    'file_changes_modes': json.loads(modes),
}
result['reset_requires_operation_id'] = 'operationId' in result['reset_required']
output = Path('/scratch/answers/prompt-settings.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
