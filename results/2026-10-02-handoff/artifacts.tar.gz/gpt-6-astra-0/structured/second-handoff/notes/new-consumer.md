# 当前前端资源使用判定

结果：`/scratch/answers/new-consumer.json`。以本次 /work 的源码字节为准，保留此前结果不覆盖。

- `packages/repa/src/server.ts:98-101`：请求体累计大小严格大于 `32 * 1024 * 1024` 才返回 413。24 MiB 为 25165824 字节，在限制内；48 MiB 为 50331648 字节，超出限制。
- `packages/repa/src/content/resources.ts:39,115,120-125`：默认 hold 为 30 分钟，建立时 expiresAt 为当前时刻加期限。未续期且宿主不活跃，40 分钟后的 get 返回 `lease_expired`。`application.ts:143-149` 的普通 detach 移除活跃状态；未显式关闭不代表仍然活跃，也不豁免过期检查。
- `packages/repa/src/protocol.ts:214` 将 settings.reset 绑定到 `SettingsResetParamsSchema`。`configuration/schema.ts:48-65` 展开 query 后，必填顶层字段为 scope、namespace、key、base，均未标记 Type.Optional；reset 不需要 value。`configuration/store.ts:150-154` 使用该 schema 校验输入。

已有 resource-policy 说明中的 64 MiB 和一小时对应较早来源修订，不适用于当前源码。此次复用其提取程序在内存中核对得到 33554432 字节和 1800000 毫秒，不覆盖历史交付。settings.reset 不属于旧 contentMethods 清单的覆盖范围，已直接核对配置协议。
