# 工作记录入口

records.json 记录已经完成的工作及其依据，原始文件和程序仍直接可用。
该记录是此前模型形成的解释，来源改变或任务超出适用范围时需要核对。

```python
import sys
sys.path.insert(0, '/scratch/work-index')
from work_records import WorkIndex
index = WorkIndex()
records = index.select()  # 或 select(ids=[...], text='字面词')；空 ids 返回空集合
changed = index.changes()  # 只核对已登记的来源；不判断业务上是否需要重建
paths = index.artifacts(ids=[...])  # 普通文件路径，可直接读取、连接和筛选
```

必要时编辑 records.json 维护说明，或继续使用普通脚本、文件与查询。
结构不负责执行业务程序、不推断未登记的依赖，也不替代来源。
