# 提示配置编辑器参数依据

结果：`/scratch/answers/prompt-settings.json`。提取程序：`/scratch/scripts/extract_prompt_settings.py`，适用于当前声明形式。

依据 `/work/project/packages/repa/src/protocol.ts:213-214`，settings.set 与 settings.reset 分别使用 configuration/schema.ts 中的 SettingsSetParamsSchema 和 SettingsResetParamsSchema，不属于 contentMethods 清单。

`configuration/schema.ts` 的 query 对象声明 scope、namespace；set 展开 query 并加入 key、value、base，reset 展开 query 并加入 key、base。这些顶层字段均未标记 Type.Optional，reset 没有 operationId。`value: Type.Unknown()` 并非可选字段。`schema.ts` 的 object 直接调用 Type.Object，不添加或删除必填字段。

SettingScopeSchema 的 kind 分支为 application、space、session；分支内部的 spaceId、sessionId 不属于 settings 方法的顶层参数。PromptSettingsSchema.fileChanges 枚举为 on-demand、notice、diff。SettingsEntrySchema.source 的 default 是来源标记，不是作用域 kind。

以上源码相对路径均位于 `/work/project/packages/repa/src`。数组按声明顺序输出；历史输出未修改。
