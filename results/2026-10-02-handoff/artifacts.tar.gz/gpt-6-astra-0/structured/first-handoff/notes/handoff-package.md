# 当前接入交付包

JSON：`/scratch/answers/handoff-package.json`。CSV：`/scratch/delivery.csv`。生成与一致性检查程序：`/scratch/scripts/build_handoff_package.py`。

四项数据分别读取 client-validation.json、integration-plan.json、changed-policy.json、prompt-settings.json。resources 使用更新后的 changed-policy.json，保留完整 cases；旧 resource-policy.json 仅作为历史留存，不纳入本交付包。资源默认值再次与当前 resources.ts、server.ts 的提取结果核对：hold 为 1800000 毫秒，上传限额为 33554432 字节。

CSV 表头为 section,key,value，每个 section 的直接字段独占一行，共 19 行数据；数组和 cases 对象保持为单个 JSON 值，不进一步展开。value 全部使用 JSON 编码，包括字符串和布尔值。程序回读 CSV 并解析每个 value，与交付 JSON 比较完全一致；同时以哈希确认已有历史 JSON 未被修改。

各模块依据与解释见同目录 client 参数清单相关记录、integration-plan.md、changed-policy.md、prompt-settings.md，以及各自提取程序。
