# 更新后的资源客户端策略

结果为 `/scratch/answers/changed-policy.json`，复用原默认值提取函数，由 `/scratch/scripts/extract_changed_policy.py` 生成。历史 `/scratch/answers/resource-policy.json`、原提取程序及说明均保留，历史值不代表更新后的实现。

当前依据为 `/work/project/packages/repa/src/content/resources.ts`（SHA-256：86cf30d6c506f53dfc7fe80293ccc5ec87cd40fe394f885d6f92a34235a7b4c0）及 `server.ts`（SHA-256：b69d229cd71a328794ef2509b75c1de6fd9b2582c4d198b8334a67c9d6142bdd）。旧开发文档未同步，默认策略以实现为准。

- ResourceRetention 构造函数：准备期仍为 10 × 60 × 1000 = 600000 毫秒；hold 默认改为 30 × 60 × 1000 = 1800000 毫秒。
- server.ts 上传分支：累计请求体大于 32 × 1024 × 1024 = 33554432 字节时返回 413；下载分支仍使用 application/octet-stream 与 attachment。
- get：先检查持有宿主身份；租约不是 hold，或期限已到且宿主不活跃时，返回 lease_expired。失联且未续期的默认 hold 在第 45 分钟已过期；仍标记活跃的宿主不受此过期判断拒绝，返回 available。
- release 将租约 kind 改为 released；renew 对非 hold 的租约返回 lease_expired，不能恢复已显式释放的使用。
- get 调用 checkOwner，另一宿主访问有效 hold 返回 permission_required。
- application.ts 的 resource.hold.get、resource.hold.renew 与 resource.release 分支直接调用上述实现。

cases 按题目指定状态做静态分支核对，忽略未指定的额外故障；不是运行测试结果。活跃宿主的 available 不表示 get 自身会刷新 expiresAt。
