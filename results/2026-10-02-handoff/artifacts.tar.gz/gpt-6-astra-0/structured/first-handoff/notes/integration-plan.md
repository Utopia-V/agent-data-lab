# 网页接入依赖清单依据

结果：`/scratch/answers/integration-plan.json`；生成程序：`/scratch/scripts/extract_integration_plan.py`。依据 `/work` 固定快照，未执行项目运行测试。

- `/work/issues/23.json`：交互产物展示与受限桥接为 #23；仅提取正文“依赖与协作”段的直接依赖，按原文顺序为 #17、#20、#21、#10，不将其他段落的关联议题或消费者计入。
- `packages/repa/src/agent/tools.ts`：`createContentTools` 返回 `[read, edit, write, patch]`；前三个名称继承 Pi 定义，patch 明确命名为 `apply_patch`。`packages/repa/test/agent-tools.test.ts:144` 及 `docs/development/content.md:3` 确认模型工具名为 read、edit、write、apply_patch。
- `packages/repa/src/protocol.ts` 的 `methods` 合并 `contentMethods` 和 `spaceMethods`；核对这些注册表，未登记 `run.steer`，已登记 `resource.hold`。`docs/development/agent-runtime.md:12` 明确 Pi 的 steer 能力尚未接通 Repa 公开接口与 Host，设计能力不能当成当前已登记协议。
- `docs/development/resources.md:50` 明确 hostKey 与主令牌只交给完整前端宿主，生成页面不直接取得完整客户端。`docs/adr/0005-execute-display-content-with-host-permissions.md` 的展示实例设计限定初始数据、资源与动作，并由宿主检查来源和授权。因此生成页面不接收完整 hostKey。

上述项目相对路径均位于 `/work/project`。程序只适用于当前已核对的源码声明形式，不是通用 TypeScript 解析器。
