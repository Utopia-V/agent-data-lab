"""Current defaults plus source-reviewed hold cases; preserves historical policy output."""
import json
from pathlib import Path
from extract_resource_policy import extract

root = Path('/work/project')
result = extract(root)
source = (root / 'packages/repa/src/content/resources.ts').read_text()
# Fail rather than silently reuse the reviewed case interpretation if its guards change.
assert 'lease.kind !== "hold" || (lease.hold.expiresAt <= this.#now() && !this.#activeHosts.has(host))' in source
assert 'if (!lease || lease.kind !== "hold") throw new RepaFault("lease_expired"' in source
assert '...lease, kind: "released", hold:' in source
assert 'if (lease.host !== host) throw new RepaFault("permission_required"' in source
assert 'this.#checkOwner(lease, host);' in source.split('  get(host:', 1)[1].split('  renew(host:', 1)[0]
result['cases'] = {
    'disconnected_after_45_minutes': 'lease_expired' if 45 * 60 * 1000 >= result['hold_ms'] else 'available',
    'active_after_45_minutes': 'available',
    'renew_after_release': 'lease_expired',
    'another_host_get': 'permission_required',
}
output = Path('/scratch/answers/changed-policy.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
