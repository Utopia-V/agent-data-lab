"""Compose the current handoff and serialize the same direct fields to CSV."""
import csv
import hashlib
import json
from pathlib import Path
from extract_resource_policy import extract

answers = Path('/scratch/answers')
inputs = {
    'parameter_filters': answers / 'client-validation.json',
    'integration': answers / 'integration-plan.json',
    'resources': answers / 'changed-policy.json',
    'settings': answers / 'prompt-settings.json',
}
# Preserve all pre-existing historical answers, including the superseded resource policy.
output = answers / 'handoff-package.json'
history = {p: hashlib.sha256(p.read_bytes()).hexdigest()
           for p in answers.glob('*.json') if p != output}
package = {section: json.loads(path.read_text()) for section, path in inputs.items()}
current_resources = extract(Path('/work/project'))
assert {k: package['resources'][k] for k in current_resources} == current_resources
assert package['resources']['hold_ms'] == 1800000
assert package['resources']['upload_limit_bytes'] == 33554432

output.write_text(json.dumps(package, ensure_ascii=False, indent=2) + '\n')
csv_path = Path('/scratch/delivery.csv')
with csv_path.open('w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['section', 'key', 'value'])
    for section, fields in package.items():
        for key, value in fields.items():
            writer.writerow([section, key, json.dumps(value, ensure_ascii=False, separators=(',', ':'))])

# Read both delivered files back and prove exact semantic equivalence.
restored = {}
with csv_path.open(newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    assert reader.fieldnames == ['section', 'key', 'value']
    rows = list(reader)
    for row in rows:
        fields = restored.setdefault(row['section'], {})
        assert row['key'] not in fields
        fields[row['key']] = json.loads(row['value'])
assert len(rows) == sum(len(fields) for fields in package.values())
assert restored == json.loads(output.read_text()) == package
assert all(hashlib.sha256(p.read_bytes()).hexdigest() == digest for p, digest in history.items())
print(f'Written and verified: {output}, {csv_path}; {len(rows)} direct-field rows; history unchanged.')
