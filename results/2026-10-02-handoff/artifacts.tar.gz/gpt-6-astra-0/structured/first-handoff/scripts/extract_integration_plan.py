"""Extract integration facts for the fixed source snapshot; see notes/integration-plan.md."""
import json
import re
from pathlib import Path
root = Path('/work/project')
issue = json.loads(Path('/work/issues/23.json').read_text())
section = issue['body'].split('## 依赖与协作', 1)[1].split('\n## ', 1)[0]
dependencies = list(dict.fromkeys(map(int, re.findall(r'#(\d+)', section))))
protocol = (root / 'packages/repa/src/protocol.ts').read_text()
content = (root / 'packages/repa/src/content/protocol.ts').read_text()
space = (root / 'packages/repa/src/spaces/schema.ts').read_text()
tools = (root / 'packages/repa/src/agent/tools.ts').read_text()
assert 'return [read, edit, write, patch];' in tools
assert 'name: "apply_patch"' in tools
assert '...contentMethods,' in protocol and '...spaceMethods,' in protocol
# The inherited Pi names are corroborated by the fixed implementation's test contract.
test = (root / 'packages/repa/test/agent-tools.test.ts').read_text()
assert '["read", "edit", "write", "apply_patch"]' in test
resources = (root / 'docs/development/resources.md').read_text()
assert '`hostKey` 与后端主令牌只交给完整前端宿主。' in resources
registered = set(re.findall(r'^\s*"([\w.]+)":\s*(?:method\(|\{\s*params:)', '\n'.join([protocol, content, space]), re.M))
result = {
    'display_bridge_issue': issue['number'],
    'display_dependencies': dependencies,
    'model_tools': ['read', 'edit', 'write', 'apply_patch'],
    'public_run_steer_registered': 'run.steer' in registered,
    'resource_hold_registered': 'resource.hold' in registered,
    'display_page_receives_host_key': False,
}
out = Path('/scratch/answers/integration-plan.json')
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(out.read_text())
