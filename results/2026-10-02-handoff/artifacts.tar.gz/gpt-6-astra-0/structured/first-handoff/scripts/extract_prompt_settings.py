"""Extract the current settings schemas, expanding the shared top-level query."""
import json
import re
from pathlib import Path
source = Path('/work/project/packages/repa/src/configuration/schema.ts').read_text()
protocol = Path('/work/project/packages/repa/src/protocol.ts').read_text()
for action in ('set', 'reset'):
    assert f'"settings.{action}": method(Settings{action.title()}ParamsSchema, SettingsViewSchema)' in protocol

def block(name):
    pattern = (r'const query = \{(.*?)\n\};' if name == 'query'
               else rf'export const {name} = object\(\{{(.*?)\n\}}\);')
    matches = re.findall(pattern, source, re.S)
    assert len(matches) == 1
    return matches[0]

def fields(text):
    return [name for name, value in re.findall(r'^  (\w+): (.*),$', text, re.M)
            if not value.startswith('Type.Optional(')]

query = fields(block('query'))
required = {}
for action in ('Set', 'Reset'):
    body = block(f'Settings{action}ParamsSchema')
    assert body.count('...query,') == 1
    required[action] = query + fields(body)
scope = source.split('export const SettingScopeSchema = Type.Union([', 1)[1].split('\n]);', 1)[0]
modes = re.search(r'fileChanges: literals\((\[[^\]]+\])\)', source)
result = {
    'set_required': required['Set'],
    'reset_required': required['Reset'],
    'scope_kinds': re.findall(r'kind: Type.Literal\("([^"]+)"\)', scope),
    'file_changes_modes': json.loads(modes[1]),
    'reset_requires_operation_id': 'operationId' in required['Reset'],
}
output = Path('/scratch/answers/prompt-settings.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
