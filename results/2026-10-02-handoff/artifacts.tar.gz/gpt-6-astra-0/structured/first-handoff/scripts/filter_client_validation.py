"""Filter the registered-method top-level parameter catalog, retaining declaration order."""
import json
from pathlib import Path

catalog = Path('/scratch/answers/method-catalog.json')
output = Path('/scratch/answers/client-validation.json')
methods = json.loads(catalog.read_text())['methods']
result = {
    'operation_without_base': [m['method'] for m in methods
                               if 'operationId' in m['required'] and 'base' not in m['required']],
    'requires_base': [m['method'] for m in methods if 'base' in m['required']],
}
assert len({m['method'] for m in methods}) == len(methods)
assert not set(result['operation_without_base']) & set(result['requires_base'])
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
