# 前端资源使用方案

结果：`/scratch/answers/new-consumer.json`。生成入口：`python3 /scratch/scripts/build_new_consumer.py`。

沿用 changed-policy、prompt-settings 和 handoff-package 的交付结论，并核对当前源码；没有覆盖历史结果。work-notes 中 resource-client-policy 记录的 64 MiB、一小时是旧修订，不适用于当前源码。

- `packages/repa/src/server.ts:89-104` 累加单次上传请求体字节数，严格超过 32 × 1024 × 1024 = 33554432 字节时返回 413。24 MiB = 25165824 字节在限制内；48 MiB = 50331648 字节超限。题设已排除认证、空间和宿主故障。
- `packages/repa/src/content/resources.ts:39,109-125` 默认 hold 期限为 30 分钟。未续期且宿主不活跃，40 分钟后 get 命中 expiresAt <= now，抛出 lease_expired；资源字节仍存在不改变该判断。`application.ts:139-149` 区分失联取消活跃与显式关闭；未显式关闭不豁免到期。`application.ts:304` 将 get 转交 retention.get。
- `packages/repa/src/protocol.ts:214` 登记 SettingsResetParamsSchema；`configuration/schema.ts:48-65` 展开 query 后，必填顶层字段为 scope、namespace、key、base，均无 Type.Optional。`schema.ts:3-4` 的 object 直接使用 Type.Object。scope 内部字段不算顶层，reset 不要求 value 或 operationId。

以上为源码静态判断，不是服务运行测试。脚本复用现有资源默认值提取器和已核对的提示配置交付数据。
