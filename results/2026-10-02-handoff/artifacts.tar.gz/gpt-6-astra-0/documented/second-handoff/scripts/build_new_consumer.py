"""Build the consumer answer from verified current resource/settings handoff data."""
import json
from pathlib import Path
from extract_resource_policy import extract

root = Path('/work/project')
scratch = Path('/scratch')
policy = extract(root)
settings = json.loads((scratch / 'answers/prompt-settings.json').read_text())
# Required fields and expired inactive-host behavior were checked against source;
# see notes/new-consumer.md. These assertions bound this snapshot-specific derivation.
assert policy['hold_ms'] == 30 * 60 * 1000
assert settings['reset_required'] == ['scope', 'namespace', 'key', 'base']
assert 40 * 60 * 1000 > policy['hold_ms']
result = {
    'upload_24_mib_allowed': 24 * 1024 * 1024 <= policy['upload_limit_bytes'],
    'upload_48_mib_allowed': 48 * 1024 * 1024 <= policy['upload_limit_bytes'],
    'inactive_hold_after_40_minutes': 'lease_expired',
    'settings_reset_required': settings['reset_required'],
}
output = scratch / 'answers/new-consumer.json'
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
assert json.loads(output.read_text()) == result
