"""Filter registered contentMethods by required top-level parameter names."""
import json
from pathlib import Path

catalog = Path('/scratch/answers/method-catalog.json')
methods = json.loads(catalog.read_text())['methods']
result = {
    'operation_without_base': [m['method'] for m in methods
                               if 'operationId' in m['required'] and 'base' not in m['required']],
    'requires_base': [m['method'] for m in methods if 'base' in m['required']],
}
output = Path('/scratch/answers/client-validation.json')
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(output.read_text())
