#!/usr/bin/env python3
"""Extract frozen Repa resource defaults and HTTP policy without executing TS."""
import argparse
import json
import math
import re
from pathlib import Path


def unique(pattern, text):
    matches = re.findall(pattern, text)
    if len(matches) != 1:
        raise ValueError(f'Expected exactly one match for {pattern!r}, got {len(matches)}')
    return matches[0]


def product(expression):
    # Only integer multiplication is accepted; no eval or source execution.
    if not re.fullmatch(r'\s*\d+(?:\s*\*\s*\d+)*\s*', expression):
        raise ValueError(f'Unsupported arithmetic: {expression!r}')
    return math.prod(int(term.strip()) for term in expression.split('*'))


def extract(root):
    retention = (root / 'packages/repa/src/content/resources.ts').read_text()
    server = (root / 'packages/repa/src/server.ts').read_text()
    preparation = unique(r'options\.preparationTtlMs\s*\?\?\s*([^;]+);', retention)
    hold = unique(r'options\.holdTtlMs\s*\?\?\s*([^;]+);', retention)
    limit = unique(r'if \(size > ([\d\s*]+)\)\s*\{\s*response\.writeHead\(413\)', server)
    # Scope the header lookup to the resource download branch, not upload or protocol.json.
    download = server.split('if (contentResource) {', 1)[1].split('let start =', 1)[0]
    return {
        'preparation_ms': product(preparation),
        'hold_ms': product(hold),
        'upload_limit_bytes': product(limit),
        'resource_download_type': unique(r'response\.setHeader\("Content-Type", "([^"]+)"\)', download),
        'resource_download_disposition': unique(r'response\.setHeader\("Content-Disposition", "([^"]+)"\)', download),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/work/project'))
    parser.add_argument('--output', type=Path, default=Path('/scratch/answers/resource-policy.json'))
    args = parser.parse_args()
    result = extract(args.root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
