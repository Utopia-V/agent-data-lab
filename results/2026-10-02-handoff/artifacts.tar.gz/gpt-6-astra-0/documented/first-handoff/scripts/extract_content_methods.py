#!/usr/bin/env python3
"""Extract this Repa snapshot's contentMethods, without executing source code.

Splits balanced TypeScript expressions so nested schema properties are excluded.
Supports object literals, local object aliases/spreads, and Type.Optional markers.
Not a general TypeScript parser; unsupported registry/parameter forms fail loudly.
"""
import argparse
import json
import re
from pathlib import Path


def split_top(text, delimiter=','):
    parts, start, stack, quote, escape = [], 0, [], None, False
    for i, char in enumerate(text):
        if quote:
            if escape:
                escape = False
            elif char == '\\':
                escape = True
            elif char == quote:
                quote = None
            continue
        if char in "\"'`":
            quote = char
        elif char in '([{':
            stack.append(char)
        elif char in ')]}':
            assert stack and stack.pop() == {')': '(', ']': '[', '}': '{'}[char]
        elif char == delimiter and not stack:
            parts.append(text[start:i].strip())
            start = i + 1
    assert not stack and not quote, 'Unbalanced expression'
    parts.append(text[start:].strip())
    return [part for part in parts if part]


def fields(expression):
    assert expression.startswith('{') and expression.endswith('}'), expression
    return split_top(expression[1:-1])


def pair(field):
    pieces = split_top(field, ':')
    assert len(pieces) == 2, field
    return pieces[0].strip('"\''), pieces[1]


def extract(source):
    # Comments do not occur in schema strings in this frozen source.
    source = re.sub(r'/\*.*?\*/|//[^\n]*', '', source, flags=re.S)
    declarations = {}
    for statement in split_top(source, ';'):
        match = re.fullmatch(r'(?:export\s+)?const\s+(\w+)\s*=\s*(.*)', statement, re.S)
        if match:
            declarations[match[1]] = match[2].strip()

    def expand(expression):
        if re.fullmatch(r'\w+', expression):
            assert expression in declarations, f'Unknown object alias: {expression}'
            return expand(declarations[expression])
        result = {}
        for field in fields(expression):
            if field.startswith('...'):
                result.update(expand(field[3:].strip()))
            elif ':' in field:
                key, value = pair(field)
                result[key] = value
            else:
                assert re.fullmatch(r'\w+', field), field
                result[field] = field
        return result

    methods = []
    for entry in fields(declarations['contentMethods']):
        name, definition = pair(entry)
        properties = dict(pair(field) for field in fields(definition))
        params = properties['params']
        assert params.startswith('object(') and params.endswith(')'), params
        parameters = expand(params[len('object('):-1].strip())
        required, optional = [], []
        for key, schema in parameters.items():
            (optional if schema.startswith('Type.Optional(') else required).append(key)
        methods.append({'method': name, 'required': required, 'optional': optional})
    assert len({item['method'] for item in methods}) == len(methods)
    return {'methods': methods}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path('/work/project/packages/repa/src/content/protocol.ts'))
    parser.add_argument('--output', type=Path, default=Path('/scratch/answers/method-catalog.json'))
    args = parser.parse_args()
    result = extract(args.source.read_text())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(f"Saved {len(result['methods'])} methods to {args.output}")


if __name__ == '__main__':
    main()
