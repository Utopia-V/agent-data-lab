"""Bundle current integration results and write a JSON-equivalent CSV."""
import csv
import json
from pathlib import Path
from extract_resource_policy import extract

scratch = Path('/scratch')
inputs = {
    'parameter_filters': 'client-validation.json',
    'integration': 'integration-plan.json',
    'resources': 'changed-policy.json',
    'settings': 'prompt-settings.json',
}
raw_inputs = {section: (scratch / 'answers' / filename).read_bytes()
              for section, filename in inputs.items()}
package = {section: json.loads(raw) for section, raw in raw_inputs.items()}
# Check current implementation defaults, rather than the historical resource policy.
current_policy = extract(Path('/work/project'))
assert all(package['resources'][key] == value for key, value in current_policy.items())
assert package['resources']['hold_ms'] == 1800000
assert package['resources']['upload_limit_bytes'] == 33554432
assert set(package['resources']['cases']) == {
    'disconnected_after_45_minutes', 'active_after_45_minutes',
    'renew_after_release', 'another_host_get',
}
output = scratch / 'answers/handoff-package.json'
output.write_text(json.dumps(package, ensure_ascii=False, indent=2) + '\n')
csv_path = scratch / 'delivery.csv'
with csv_path.open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['section', 'key', 'value'])
    for section, fields in package.items():
        for key, value in fields.items():
            writer.writerow([section, key, json.dumps(value, ensure_ascii=False, separators=(',', ':'))])

reconstructed = {section: {} for section in package}
with csv_path.open(newline='') as stream:
    reader = csv.DictReader(stream)
    assert reader.fieldnames == ['section', 'key', 'value']
    for row in reader:
        assert row['key'] not in reconstructed[row['section']]
        reconstructed[row['section']][row['key']] = json.loads(row['value'])
assert reconstructed == json.loads(output.read_text()) == package
for section, filename in inputs.items():
    assert (scratch / 'answers' / filename).read_bytes() == raw_inputs[section]
print(json.dumps({'result_path': str(output), 'csv_path': str(csv_path),
                  'rows': sum(map(len, package.values())), 'round_trip': 'passed'}))
