#!/usr/bin/env python3
"""Identify task-owner issues by their titles in the frozen local snapshot.

Issue state is intentionally not used to infer implementation status.
"""
import argparse
import json
from pathlib import Path

TOPICS = {
    'resource_backend_issue': '内容与资源生命周期',
    'requests_issue': '请求与会话运行',
    'shell_issue': '命令工具与执行权限',
    'material_search_issue': '材料处理与检索',
    'display_bridge_issue': '交互产物展示与受限桥接',
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--issues', type=Path, default=Path('/work/issues'))
    parser.add_argument('--output', type=Path, default=Path('/scratch/answers/task-owners.json'))
    args = parser.parse_args()
    issues = [json.loads(p.read_text()) for p in sorted(args.issues.glob('*.json'))]
    result = {}
    for key, title_fragment in TOPICS.items():
        matches = [issue for issue in issues if title_fragment in issue['title']]
        if len(matches) != 1:
            raise ValueError(f'{key}: expected one matching issue, found {len(matches)}')
        number = matches[0]['number']
        assert type(number) is int
        result[key] = number
    assert len(set(result.values())) == len(TOPICS)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
