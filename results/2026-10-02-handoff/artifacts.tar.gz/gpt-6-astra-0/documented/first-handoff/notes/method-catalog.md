# Repa 内容方法清单

结果：`/scratch/answers/method-catalog.json`。
源码快照：`040aa16d7c7a142cdebf39388486c1bc65a98387`（见 `/work/SOURCE.md`）。

范围以 `/work/project/packages/repa/src/content/protocol.ts:18-54` 的 `contentMethods` 为准，共 25 个方法：content 12 个、material 1 个、operation 4 个、resource 5 个、context 3 个。不按 `content.` 前缀过滤，也不扩展到总协议中其他注册表的方法。

字段按源码声明顺序输出。展开同文件的 `operation`、`target`、`ref`、`space` 对象别名和 spread；仅读取 `params` 对象顶层属性。顶层 `Type.Optional(...)` 为可选，其他为必填。`target`、`ref`、`destination`、`binding` 等内部字段不展开，返回值不计入参数。

核对依据：
- `/work/project/packages/repa/src/content/protocol.ts:11-54`：对象别名、全部方法与参数声明。
- `/work/project/packages/repa/src/schema.ts:3-10`：`object` 直接调用 `Type.Object`，不改变属性可选性；`id` 和 `revision` 均非可选 schema。
- `/work/project/packages/repa/src/content/schema.ts`：参数引用的领域 schema 非顶层 Optional；例如 `ContextBindingSchema` 允许 null，但 `context.set.binding` 仍为必填。
- `/work/project/packages/repa/src/protocol.ts:209-211`：总协议纳入 `contentMethods`。

复用提取程序：

```sh
python3 /scratch/scripts/extract_content_methods.py \
  --source /work/project/packages/repa/src/content/protocol.ts \
  --output /scratch/answers/method-catalog.json
```

程序为当前声明形式的静态提取器，不执行项目代码或安装依赖。使用括号层级区分顶层属性和嵌套 schema，支持本地对象别名、对象 spread、简写属性及直接 Optional 标记；不是通用 TypeScript 解释器。换用新版本源码时，需重新核对导入 schema 是否变为 Optional，以及是否引入未支持的声明形式。

已核对输出全部 25 个方法与注册表顺序一致，required/optional 无交集，合计 65 个必填字段和 10 个可选字段。
