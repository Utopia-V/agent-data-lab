# 生成网页接入依赖依据

结果：`/scratch/answers/integration-plan.json`。

- `/work/issues/23.json`：交互产物展示与受限桥接 Issue 为 23；仅从“依赖与协作”段提取全部直接依赖，依正文顺序为 17、20、21、10。正文其他关联、契约和消费者编号不纳入。
- `/work/project/packages/repa/src/agent/tools.ts`：`createContentTools` 返回 `[read, edit, write, patch]`；前三者继承 Pi 工具名，patch 的 name 为 `apply_patch`。`/work/project/packages/repa/test/agent-tools.test.ts:144` 明确断言实际名称列表为 `["read", "edit", "write", "apply_patch"]`；此处为静态核对，未运行测试。
- `/work/project/packages/repa/src/protocol.ts`：公开 `methods` 展开 `contentMethods` 和 `spaceMethods`；自身只登记 `run.submit`、`run.get`、`run.cancel`，连同两个展开表均无 `run.steer`。`/work/project/packages/repa/src/content/protocol.ts:46` 已登记 `resource.hold`。空间表位于 `/work/project/packages/repa/src/spaces/schema.ts`。
- `/work/project/docs/development/resources.md:48-50`：完整 `hostKey` 与后端主令牌只交给完整前端宿主，生成页面使用受限桥接，不直接取得完整客户端。因此页面获得完整 hostKey 为 false。
