# 更新后的资源客户端策略

结果：`/scratch/answers/changed-policy.json`。历史结果 `/scratch/answers/resource-policy.json` 与原说明保持不变；旧开发文档中的一小时默认期限不用于本次判断。

当前源码 `packages/repa/src/content/resources.ts` 构造函数：准备期 `10 * 60 * 1000 = 600000` 毫秒；默认 hold `30 * 60 * 1000 = 1800000` 毫秒。
当前源码 `packages/repa/src/server.ts`：上传请求体严格超过 `32 * 1024 * 1024 = 33554432` 字节返回 HTTP 413；资源下载仍使用 `application/octet-stream` 和 `attachment`。
上述五项复用 `/scratch/scripts/extract_resource_policy.py`，以显式 `--output /scratch/answers/changed-policy.json` 提取，未覆盖历史输出。

cases 按当前 ResourceRetention 实现静态推导，忽略题目未指明的额外故障：
- disconnected_after_45_minutes：45 分钟超过未续期的 30 分钟默认期限，宿主不在 activeHosts 中，get 返回 lease_expired。
- active_after_45_minutes：get 对仍标记活跃的宿主豁免 expiresAt 到期检查，返回 available；即使未 checkpoint 续期也成立。
- renew_after_release：release 将 kind 改为 released；renew 对 kind 非 hold 直接返回 lease_expired。
- another_host_get：get 先执行 checkOwner；有效 hold 的 host 与访问宿主不一致，返回 permission_required。

`packages/repa/src/application.ts:304-305` 将 resource.hold.get、resource.hold.renew 分别直接转交 retention.get、retention.renew。以上为固定实现核对，不是运行时测试结果。
