# 提示配置编辑器参数依据

结果：`/scratch/answers/prompt-settings.json`。

`/work/project/packages/repa/src/protocol.ts:213-214` 将 settings.set 和 settings.reset 分别登记为 SettingsSetParamsSchema 与 SettingsResetParamsSchema。

`/work/project/packages/repa/src/configuration/schema.ts` 的 query 展开为 scope、namespace；set 增加 key、value、base；reset 增加 key、base。全部顶层字段均未标为 Type.Optional，value 的 Type.Unknown 也未标为可选。reset 不声明 operationId。

同文件 SettingScopeSchema 的 kind 联合值为 application、space、session；PromptSettingsSchema.fileChanges 的枚举为 on-demand、notice、diff。scope 内部的 spaceId、sessionId 不列入方法顶层参数；SettingsEntrySchema.source 的 default 不是作用域 kind。

`/work/project/packages/repa/src/schema.ts` 的 object 直接构造 Type.Object，未改变必填性；literals 使用 Type.Enum。输出顺序沿用声明顺序。本次静态核对，不依赖此前 contentMethods 清单。
