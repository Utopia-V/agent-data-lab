# Repa 资源客户端接入策略

结果文件：`/scratch/answers/resource-policy.json`。
依据 `/work/SOURCE.md` 标识的源码快照 `040aa16d7c7a142cdebf39388486c1bc65a98387`，核对实现及随附开发文档。

| 项目 | 实际声明和换算 | 来源（路径相对于 `/work/project`） |
| --- | --- | --- |
| 默认 preparation 期限 | `10 * 60 * 1000` = 600000 毫秒，即十分钟 | `packages/repa/src/content/resources.ts:38`；`docs/development/resources.md:15` |
| 默认 hold 期限 | `60 * 60 * 1000` = 3600000 毫秒，即一小时 | `packages/repa/src/content/resources.ts:39`；`docs/development/resources.md:52` |
| 单次 HTTP 上传字节上限 | `64 * 1024 * 1024` = 67108864 字节，即 64 MiB | `packages/repa/src/server.ts:89-104`；`docs/development/content.md:90` |
| 资源下载 Content-Type | `application/octet-stream` | `packages/repa/src/server.ts:118-122`；`docs/development/resources.md:3` |
| 资源下载 Content-Disposition | `attachment`，未附带 filename 参数 | `packages/repa/src/server.ts:122`；文档同上说明采用下载形式 |

这些期限是默认运行策略，不是资源的固定最长寿命。`ApplicationOptions.resources` 允许调整期限和时钟（`application.ts:46`、`resources.ts:20-23`；`docs/development/resources.md:54`）。preparation 的到期时间为创建时钟加 preparation TTL（`resources.ts:92-99`）。hold 新建和续期使用当前时钟加 hold TTL；活跃宿主会被自动续期，普通期限已过但宿主仍活跃时仍保留字节（`resources.ts:109-134,163-174`）。长期使用上传或预览所得资源时，应在准备期内交给文档等持久消费者或建立 hold；过期不代表 blob 当场被删除，回收由显式 `resource.collect` 触发（`docs/development/resources.md:44,62`）。

HTTP 上传使用 `POST /spaces/<spaceId>/resources`。服务端累加请求体各 chunk 的字节数，只有 `size > 67108864` 才返回 413，因此恰好 64 MiB 不因大小检查被拒绝。该上限是请求体字节数，不是字符数，也不是 WebSocket 的 maxPayload。

下载使用 `GET` 或 `HEAD /spaces/<spaceId>/resources/<id>`，包括单字节范围响应，均设置上述两个下载头。客户端展示类型应使用资源引用中的 `mediaType`，不能将下载响应的通用 Content-Type 当作原始媒体类型。上传响应的 `application/json` 和 `/protocol.json` 的类型不属于资源下载策略。

## 提取方法

运行：

```sh
python3 /scratch/scripts/extract_resource_policy.py
```

可用 `--root` 和 `--output` 指定其他源码目录和输出文件。程序定位 TTL 默认表达式、HTTP 413 大小条件和下载分支内的两个响应头；整数乘法以拆分因子计算，不执行源码。声明模式变化时需重新核对提取逻辑。当前结果已与上述文档的十分钟、一小时、64 MiB 和下载响应说明核对一致。
