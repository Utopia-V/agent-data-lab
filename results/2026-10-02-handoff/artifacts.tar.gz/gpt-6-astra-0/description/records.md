# 已完成工作的说明

来源版本只表示实际文件字节；未登记的依赖需要自行核对。

## content-method-catalog · contentMethods 顶层参数清单及静态提取程序

用途：为 Repa 内容客户端提供当前登记方法及其顶层必填、可选字段。结果包含 methods 数组，每项为 method、required、optional；共 25 个方法，覆盖 content、material、operation、resource、context 命名空间。配套说明记录对象别名展开、可选性判定与来源核对。

适用条件：依据固定源码快照 040aa16d7c7a142cdebf39388486c1bc65a98387，仅覆盖 contentMethods，不是总协议的全部方法；不展开嵌套参数，不列返回值。程序支持当前声明形式的对象别名、spread、简写属性及直接 Type.Optional 标记，不是通用 TypeScript 解析器，也不执行项目代码。导入 schema 的顶层可选性已按当前源码核对，换用新源码需重新核对，不能仅依赖程序推断。

入口：直接读取 /scratch/answers/method-catalog.json 和 /scratch/notes/method-catalog.md。已有程序调用方式：python3 /scratch/scripts/extract_content_methods.py --source /work/project/packages/repa/src/content/protocol.ts --output <输出文件路径>；省略 --output 会写入原结果，本次仅登记而未重跑。

工件：
- scripts/extract_content_methods.py
- answers/method-catalog.json
- notes/method-catalog.md

依据及字节版本：
- SOURCE.md：9d0231ccb083e634db94c3e4059e873cfd2f96d0de124da53aea7577b586f1d0
- project/packages/repa/src/content/protocol.ts：39ab5f3c1c34b3dce40acca00c78690266ec4141fdba9e668502e4635852827c
- project/packages/repa/src/schema.ts：32c6482bf3cef8a43678f339523ec42bc4e0483cf20abbc04bae40f1f1647f42
- project/packages/repa/src/content/schema.ts：e4769b0917ae5f4d81944176cf1179459a8c45b0cf6dc10b9ee6e934fcc79ba5
- project/packages/repa/src/protocol.ts：4ea86652974e7ff72fd6c7beaab7747b6182d0aed2bdc59684ce522453703ed2

依赖的工作：

## resource-client-policy · 资源客户端默认期限与 HTTP 策略核对

用途：提供 preparation_ms、hold_ms、upload_limit_bytes、resource_download_type、resource_download_disposition 五项接入数据。已有结果分别为 600000 毫秒、3600000 毫秒、67108864 字节、application/octet-stream、attachment。配套说明保存算式、实现与文档依据，并解释租约、上传边界和下载媒体类型的使用方式。

适用条件：依据同一固定源码快照及随附文档，记录默认运行策略而非不可配置的最长资源寿命。期限可通过 ApplicationOptions.resources 调整，活跃宿主的 hold 会续期；租约到期不等于字节即时删除。上传上限针对单次 HTTP 请求体，严格大于上限才因大小返回 413，不是 WebSocket 限额。下载响应使用通用媒体类型，实际展示类型取资源引用的 mediaType。程序按当前源码模式提取并只计算整数乘法，不进行 HTTP 运行测试或自动理解变化后的声明。

入口：直接读取 /scratch/answers/resource-policy.json 和 /scratch/notes/resource-policy.md。已有程序调用方式：python3 /scratch/scripts/extract_resource_policy.py --root /work/project --output <输出文件路径>；默认输出为原结果，本次未执行提取程序。

工件：
- scripts/extract_resource_policy.py
- answers/resource-policy.json
- notes/resource-policy.md

依据及字节版本：
- SOURCE.md：9d0231ccb083e634db94c3e4059e873cfd2f96d0de124da53aea7577b586f1d0
- project/packages/repa/src/content/resources.ts：8ccd3803dac08d814ed4d94d2abd9ebf8415a4df7208f3d951920ac79b37557d
- project/packages/repa/src/server.ts：4e071783e04b7216f50f6debd3609988d1cfc16dfe3de35c42d92ed0402208f4
- project/packages/repa/src/application.ts：d9905c90b3a9e185705e12d5acd248b57060063d9caa44049accac0f832fbeeb
- project/docs/development/resources.md：f0e9e65992dc2b68679b764198052b64d8cb15de764fe3c7a329da3b824528f8
- project/docs/development/content.md：2a9026721fb1da2ef21e28c4c3ee705f1c533641a7d6d463a5c77e768ba0b51f

依赖的工作：

## integration-task-owners · 接入任务 Issue 归属与现有能力边界说明

用途：将资源后端、请求投递、命令执行、材料检索、交互产物桥接分别映射至 Issue 17、19、21、22、23，保存为五个整数编号字段。配套说明整理责任边界、已有能力和消费者接入缺口，并引用已有方法清单与资源策略，供交接读取。

适用条件：归属来自本地 2026-09-28 Issue 快照的标题和正文，实现边界参照随附开发文档；不是线上实时状态。OPEN 不代表正文中的所有能力都未实现：#17 正文已记录基础实现进入 dev，但不意味着请求、展示等消费者全部接通。正文记录的测试通过不是本次重新运行测试的结论。提取程序只按标题主题匹配唯一 Issue 并读取编号，不会分析实现完成度；说明中的责任解释来自已完成的正文核对。标题变化或任务拆分后需要重新核对。depends_on 表示配套说明引用已有工作，不表示编号提取程序运行时依赖这些结果。

入口：直接读取 /scratch/answers/task-owners.json 和 /scratch/notes/task-owners.md。已有程序调用方式：python3 /scratch/scripts/extract_task_owners.py --issues /work/issues --output <输出文件路径>；默认输出为原结果，本次未执行提取程序。

工件：
- scripts/extract_task_owners.py
- answers/task-owners.json
- notes/task-owners.md

依据及字节版本：
- SOURCE.md：9d0231ccb083e634db94c3e4059e873cfd2f96d0de124da53aea7577b586f1d0
- issues/17.json：a4f8ac3d598e23326f2cf6bbefc0d320c46d0bc0102fdd5f1299230370512209
- issues/19.json：334586349f82403c4e0e3bdc378f093933056ec5999174c926d4e96ccbd5d99d
- issues/21.json：0037b0a073903c9ccbb6c6a0da621ba0b6f94b74baa4d3d0c235621bfd571d51
- issues/22.json：02a131ef1b7c0594ac40a88fb9ff626b2baf371669ef09d4091a2307adc46c5c
- issues/23.json：f020f653f500e916ae46dd0fbff97dadf57bc5fd108cdffd94f62137bc15e7ce
- project/docs/development/agent-runtime.md：4bf48f3922a78e13c4d80f9cf15e110ee1c1410f2ee6495b9c34a242d416167b
- project/docs/development/content.md：2a9026721fb1da2ef21e28c4c3ee705f1c533641a7d6d463a5c77e768ba0b51f
- project/docs/development/resources.md：f0e9e65992dc2b68679b764198052b64d8cb15de764fe3c7a329da3b824528f8
- project/docs/development/spaces.md：a6315ac9053198e1ac0b720d53c0af35691953b35f597b1a9844fc72978885d8

依赖的工作：
- content-method-catalog
- resource-client-policy

