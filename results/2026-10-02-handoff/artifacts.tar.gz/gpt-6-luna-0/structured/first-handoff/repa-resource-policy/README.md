# Repa resource client policy

`/scratch/answers/changed-policy.json` is the current client policy, extracted
from `packages/repa/src/content/resources.ts` and `packages/repa/src/server.ts`.
It includes the four requested hold-lifecycle outcomes. Implementation is
source of truth; `docs/development/resources.md` and `content.md` may lag.

Regenerate from the fixed source with:

```sh
python3 /scratch/repa-resource-policy/extract_resource_policy.py /work/project /scratch/answers/changed-policy.json
```

`/scratch/answers/resource-policy.json` is retained as the earlier historical
output and is not the current policy.
