#!/usr/bin/env python3
"""Extract current Repa resource policy and specified lifecycle outcomes.

Implementation is authoritative when development docs lag. Usage:
  python3 extract_resource_policy.py [project-root] [output.json]
"""
import json, math, re, sys
from pathlib import Path
root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/work/project')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/scratch/answers/changed-policy.json')
resources = (root / 'packages/repa/src/content/resources.ts').read_text()
server = (root / 'packages/repa/src/server.ts').read_text()
def ttl(name):
    m = re.search(rf'this\.#{name}Ttl\s*=\s*options\.{name}TtlMs\s*\?\?\s*(\d+)\s*\*\s*(\d+)\s*\*\s*(\d+)', resources)
    if not m: raise SystemExit(f'Could not find default {name} TTL expression')
    return math.prod(map(int, m.groups()))
limit_match = re.search(r'if \(size > (\d+) \* (\d+) \* (\d+)\)', server)
if not limit_match: raise SystemExit('Could not find HTTP upload byte limit')
headers = re.search(r'response\.setHeader\("Content-Type",\s*"([^"]+)"\);\s*response\.setHeader\("Content-Disposition",\s*"([^"]+)"\);', server)
if not headers: raise SystemExit('Could not find resource download headers')
# These outcomes follow ResourceRetention.get/renew/release and ownership checks.
# Keep the focused scenarios explicit; unrelated missing-resource faults are excluded.
result = {
 'preparation_ms': ttl('preparation'),
 'hold_ms': ttl('hold'),
 'upload_limit_bytes': math.prod(map(int, limit_match.groups())),
 'resource_download_type': headers.group(1),
 'resource_download_disposition': headers.group(2),
 'cases': {
  'disconnected_after_45_minutes': 'lease_expired',
  'active_after_45_minutes': 'available',
  'renew_after_release': 'lease_expired',
  'another_host_get': 'permission_required',
 },
}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(f'Wrote {out}')
