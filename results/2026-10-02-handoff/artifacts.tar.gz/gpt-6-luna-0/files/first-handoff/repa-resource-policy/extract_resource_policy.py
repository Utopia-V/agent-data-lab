#!/usr/bin/env python3
"""Extract and cross-check current Repa resource HTTP/lifetime defaults.

Usage: python3 extract_resource_policy.py [project-root] [output.json]
The lifetime defaults are read from content/resources.ts; upload size and
response headers are read from server.ts. The documentation is checked for the
same stated TTL and 64 MiB upload maximum.
"""
import json, re, sys
from pathlib import Path
root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/work/project')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/scratch/answers/resource-policy.json')
resources = (root / 'packages/repa/src/content/resources.ts').read_text()
server = (root / 'packages/repa/src/server.ts').read_text()
doc_resources = (root / 'docs/development/resources.md').read_text()
doc_content = (root / 'docs/development/content.md').read_text()
def ttl(name):
    m = re.search(rf'this\.#{name}Ttl\s*=\s*options\.{name}TtlMs\s*\?\?\s*(\d+)\s*\*\s*(\d+)\s*\*\s*(\d+)', resources)
    if not m: raise SystemExit(f'Could not find default {name} TTL expression')
    a,b,c = map(int,m.groups())
    return a*b*c
limit_match = re.search(r'if \(size > (\d+) \* (\d+) \* (\d+)\)', server)
if not limit_match: raise SystemExit('Could not find HTTP upload byte limit')
upload_limit = __import__('math').prod(map(int, limit_match.groups()))
type_match = re.search(r'response\.setHeader\("Content-Type",\s*"([^"]+)"\);\s*response\.setHeader\("Content-Disposition",\s*"([^"]+)"\);', server)
if not type_match: raise SystemExit('Could not find resource download headers')
preparation_ms, hold_ms = ttl('preparation'), ttl('hold')
if '默认十分钟到期' not in doc_resources or '默认租约为一小时' not in doc_resources:
    raise SystemExit('Lifetime defaults do not match resources.md')
if '64 MiB' not in doc_content: raise SystemExit('Upload limit does not match content.md')
result = {
 'preparation_ms': preparation_ms,
 'hold_ms': hold_ms,
 'upload_limit_bytes': upload_limit,
 'resource_download_type': type_match.group(1),
 'resource_download_disposition': type_match.group(2),
}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(f'Wrote {out}')
