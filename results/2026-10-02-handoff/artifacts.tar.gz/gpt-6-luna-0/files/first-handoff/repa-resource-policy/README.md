# Repa resource client policy

`/scratch/answers/resource-policy.json` records the current defaults and HTTP
resource-download headers. The TTL values are milliseconds calculated from
`packages/repa/src/content/resources.ts` (`10 * 60 * 1000` and
`60 * 60 * 1000`). The upload limit comes from the HTTP request-body guard in
`packages/repa/src/server.ts` (`64 * 1024 * 1024`, 64 MiB). That handler sets
`Content-Type: application/octet-stream` and `Content-Disposition: attachment`
for resource downloads. `docs/development/resources.md` confirms the preparation
and hold periods; `docs/development/content.md` confirms the upload limit.

Regenerate and cross-check:

```sh
python3 /scratch/repa-resource-policy/extract_resource_policy.py /work/project /scratch/answers/resource-policy.json
```
