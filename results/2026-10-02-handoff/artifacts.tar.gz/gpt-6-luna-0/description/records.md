# 已完成工作的说明

来源版本只表示实际文件字节；未登记的依赖需要自行核对。

## repa-content-method-catalog · Repa 内容协议方法清单

用途：列出 contentMethods 登记的全部方法（含 material、operation、resource、context 命名空间）及每个方法的顶层必填和可选参数；JSON 可供客户端接入查阅。

适用条件：依据当前冻结源码 packages/repa/src/content/protocol.ts 的 contentMethods 声明；只列顶层参数，不展开 target、ref 等参数内部 schema。现有提取器用源声明注册名顺序校验其参数清单；源码形状或参数声明变化后须先核对并更新清单。

入口：运行 python3 /scratch/repa-method-catalog/extract_content_methods.py /work/project /scratch/answers/method-catalog.json 重新生成；直接读取 /scratch/answers/method-catalog.json 获取结果。

工件：
- answers/method-catalog.json
- repa-method-catalog/extract_content_methods.py
- repa-method-catalog/README.md

依据及字节版本：
- project/packages/repa/src/content/protocol.ts：39ab5f3c1c34b3dce40acca00c78690266ec4141fdba9e668502e4635852827c

依赖的工作：

## repa-resource-client-policy · Repa 资源客户端策略参数

用途：记录 preparation 与 hold 的默认有效期、单次 HTTP 上传字节上限，以及资源下载响应的 Content-Type 和 Content-Disposition，供资源客户端接入参考。

适用条件：反映当前本地源码与对应开发文档的默认值及 HTTP 实现；TTL 配置可以覆盖默认期限。上传上限是 server.ts 上传请求体检查中的字节数，下载头仅指资源下载路由响应。

入口：运行 python3 /scratch/repa-resource-policy/extract_resource_policy.py /work/project /scratch/answers/resource-policy.json 重新提取并交叉核对；直接读取 /scratch/answers/resource-policy.json 获取结果。

工件：
- answers/resource-policy.json
- repa-resource-policy/extract_resource_policy.py
- repa-resource-policy/README.md

依据及字节版本：
- project/packages/repa/src/content/resources.ts：8ccd3803dac08d814ed4d94d2abd9ebf8415a4df7208f3d951920ac79b37557d
- project/packages/repa/src/server.ts：4e071783e04b7216f50f6debd3609988d1cfc16dfe3de35c42d92ed0402208f4
- project/docs/development/resources.md：f0e9e65992dc2b68679b764198052b64d8cb15de764fe3c7a329da3b824528f8
- project/docs/development/content.md：2a9026721fb1da2ef21e28c4c3ee705f1c533641a7d6d463a5c77e768ba0b51f

依赖的工作：

## repa-task-ownership-map · Repa 后续接入任务归属

用途：将资源后端、请求投递、命令执行、材料检索和交互产物桥接五类工作映射到对应 Issue 编号，并附上快照中已明确的责任边界、接入提示和已实现状态说明。

适用条件：依据本地冻结的 Issue 正文，不以 OPEN 状态推断工作尚未实现；仅表示快照描述的归属与进展，开始工作前仍需按项目当前源码和文档确认实际状态。

入口：读取 /scratch/answers/task-owners.json 获取编号映射；按需阅读 /scratch/repa-task-owners/README.md 查看交接说明。

工件：
- answers/task-owners.json
- repa-task-owners/README.md

依据及字节版本：
- issues/17.json：a4f8ac3d598e23326f2cf6bbefc0d320c46d0bc0102fdd5f1299230370512209
- issues/19.json：334586349f82403c4e0e3bdc378f093933056ec5999174c926d4e96ccbd5d99d
- issues/21.json：0037b0a073903c9ccbb6c6a0da621ba0b6f94b74baa4d3d0c235621bfd571d51
- issues/22.json：02a131ef1b7c0594ac40a88fb9ff626b2baf371669ef09d4091a2307adc46c5c
- issues/23.json：f020f653f500e916ae46dd0fbff97dadf57bc5fd108cdffd94f62137bc15e7ce

依赖的工作：

