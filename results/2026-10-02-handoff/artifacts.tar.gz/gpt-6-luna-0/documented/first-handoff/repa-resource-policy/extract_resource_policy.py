#!/usr/bin/env python3
"""Extract current resource defaults and hold-state outcomes from Repa source.

Usage: python3 extract_resource_policy.py [project-root] [output.json]
The implementation is authoritative; development docs may lag while being
synchronized. The state cases match ResourceRetention.get/renew/release logic.
"""
import json, math, re, sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/work/project')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/scratch/answers/resource-policy.json')
resources = (root / 'packages/repa/src/content/resources.ts').read_text()
server = (root / 'packages/repa/src/server.ts').read_text()
def ttl(name):
    m = re.search(rf"this[.]#{name}Ttl\s*=\s*options[.]{name}TtlMs\s*[?][?]\s*([0-9]+)\s*[ *]+\s*([0-9]+)\s*[ *]+\s*([0-9]+)", resources)
    if not m: raise SystemExit(f'Could not find default {name} TTL expression')
    return math.prod(map(int, m.groups()))
limit_match = re.search(r"if [(]size > ([0-9]+) [*] ([0-9]+) [*] ([0-9]+)[)]", server)
if not limit_match: raise SystemExit('Could not find HTTP upload byte limit')
type_match = re.search(r"response[.]setHeader[(]\"Content-Type\",\s*\"([^\"]+)\"[)];\s*response[.]setHeader[(]\"Content-Disposition\",\s*\"([^\"]+)\"[)];", server)
if not type_match: raise SystemExit('Could not find resource download headers')
# Guard the case interpretation against implementation changes.
get_body = resources.split('  get(host:', 1)[1].split('\n  renew(', 1)[0]
renew_body = resources.split('  renew(host:', 1)[1].split('\n  release(', 1)[0]
release_body = resources.split('  release(host:', 1)[1].split('\n  releaseHost(', 1)[0]
if 'lease.hold.expiresAt <= this.#now() && !this.#activeHosts.has(host)' not in get_body:
    raise SystemExit('Resource get expiration/activity behavior changed; review cases')
if 'lease.kind !== "hold"' not in renew_body or 'this.#checkOwner(lease, host)' not in renew_body:
    raise SystemExit('Resource renew behavior changed; review cases')
if 'kind: "released"' not in release_body:
    raise SystemExit('Resource release behavior changed; review cases')
result = {
 'preparation_ms': ttl('preparation'),
 'hold_ms': ttl('hold'),
 'upload_limit_bytes': math.prod(map(int, limit_match.groups())),
 'resource_download_type': type_match.group(1),
 'resource_download_disposition': type_match.group(2),
 'cases': {
  'disconnected_after_45_minutes': 'lease_expired',
  'active_after_45_minutes': 'available',
  'renew_after_release': 'lease_expired',
  'another_host_get': 'permission_required',
 },
}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(f'Wrote {out}')
