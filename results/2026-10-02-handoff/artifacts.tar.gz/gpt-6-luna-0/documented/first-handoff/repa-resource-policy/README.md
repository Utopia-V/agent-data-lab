# Repa resource client policy

`/scratch/answers/changed-policy.json` records the current implementation defaults,
HTTP resource-download headers, and outcomes of four hold-state cases. The
implementation is authoritative; the development docs have not yet been synced
with the latest TTL and upload-limit changes. Hold outcomes follow
`ResourceRetention.get`, `renew`, and `release` in
`packages/repa/src/content/resources.ts`.

Regenerate from the current source:

```sh
python3 /scratch/repa-resource-policy/extract_resource_policy.py /work/project /scratch/answers/changed-policy.json
```

`/scratch/answers/resource-policy.json` is the preserved earlier snapshot; do not
overwrite it when refreshing current values.
