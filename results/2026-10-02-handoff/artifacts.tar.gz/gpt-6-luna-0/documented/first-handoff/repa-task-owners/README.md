# Repa task ownership handoff

The issue numbers in `/scratch/answers/task-owners.json` map the five requested
areas to the local frozen issue snapshots under `/work/issues/`. Ownership was
matched by each issue's stated responsibility and title, not by OPEN state.

| Area | Issue | Handoff context from snapshot |
| --- | ---: | --- |
| Resource backend | #17 | Explicitly says content/resource/space lifecycle is already implemented on `dev` (original commit `86d2b2d7f`) and Linux backend plus both host integration tests passed on the unified baseline. Reuse the current interfaces; this is not a signal to rebuild resource retention. See `docs/development/content.md`, `resources.md`, and `spaces.md`. |
| Requests | #19 | Owns durable request/run/queue facts, submission identity, request inputs/resources, delivery association, failure continuation, and background requests. The snapshot describes `run.submit` as a text-only prototype with requestId/start-run conflated and busy returning `busy`; it calls for reusing Pi delivery (`steer`, `followUp`, `prompt`, session history) rather than reimplementing the loop. Basic delivery can proceed before the entire #18 model-connection work. |
| Shell | #21 | Owns execution adapter, actual authorization and isolation, cancellation/process lifecycle, plus sandbox helper integration. Reuse Pi's bash tool factory and connect through `BashOperations.exec`; do not mistake a UI toggle for enforced sandboxing. Shell file changes follow content external-edit observation, not FileJournal transaction semantics. |
| Material search | #22 | Owns content/history search query, snippets, source location, paging/status and material representations/extraction. It explicitly says material association/common persistence already implemented under #6 should be reused. Prefer Pi grep/find/ls or `rg` where authorization boundaries are actually enforced; do not conflate material extraction, content search, history search, or ordinary file search. |
| Display bridge | #23 | Cross-end issue: backend owns instance identity, authorization, resources, action protocol and result data; frontend owner schedules renderer, bridge client, isolation and interaction work under #10. Requires coordinated validation of actual rendered content and security boundary. Explicit dependencies: #17, #20, #21, #10. |

These notes summarize intended ownership and implementation state described by
frozen issue bodies. Verify the current `dev` source/docs before beginning work;
OPEN is workflow status and is not evidence that every stated deliverable remains
unimplemented.
