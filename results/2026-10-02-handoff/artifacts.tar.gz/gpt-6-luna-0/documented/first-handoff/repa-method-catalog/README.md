# Repa content method catalog

`/scratch/answers/method-catalog.json` catalogs every method registered by
`packages/repa/src/content/protocol.ts`'s `contentMethods` object, including
`material.*`, `operation.*`, `resource.*`, and `context.*` namespaces. Parameter
lists are top-level only: spread aliases such as `target` are represented as a
single field; nested members of their schemas are not expanded. `required` and
`optional` follow the corresponding TypeBox top-level declaration and
`Type.Optional` wrappers.

Regenerate from the frozen source with:

```sh
python3 /scratch/repa-method-catalog/extract_content_methods.py /work/project /scratch/answers/method-catalog.json
```

The script checks that the registration names and order still match its
source-derived parameter manifest, and stops if registrations change, prompting
an update after checking the declarations. Source: `/work/project/packages/repa/src/content/protocol.ts`.
