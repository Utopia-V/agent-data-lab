#!/usr/bin/env python3
"""Build the top-level contentMethods catalog for this Repa source revision.

The source uses TypeBox object schemas with nested fields and spread aliases, so
this manifest records only top-level params. It is checked against the actual
contentMethods registrations before output. Required/optional status comes from
whether the declared top-level property is wrapped in Type.Optional(...).
Run: python3 extract_content_methods.py [project-root] [output.json]
"""
import json
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/work/project')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/scratch/answers/method-catalog.json')
source = (root / 'packages/repa/src/content/protocol.ts').read_text()
# Source declaration manifest, in registration order. Includes expanded top-level
# spread aliases (`target`, `operation`, `space`, `ref`). Nested schema fields do
# not appear here.
spec = [
 ('content.list', ['spaceId'], []), ('content.get', ['target'], []),
 ('content.read', ['target'], ['offset','limit','revision']),
 ('content.write', ['target','operationId','value','base'], []),
 ('content.edit', ['target','operationId','edits'], []),
 ('content.applyPatch', ['spaceId','operationId','patch'], []),
 ('content.move', ['target','operationId','destination','base'], ['container']),
 ('content.copy', ['target','operationId','destination','base'], ['container']),
 ('material.collect', ['target','operationId','destination','base'], []),
 ('content.associate', ['spaceId','operationId','location','role'], ['id']),
 ('content.relink', ['ref','operationId','location','base'], []),
 ('content.remove', ['target','operationId','base'], ['detach']),
 ('content.setComposition', ['ref','operationId','base','members','resources'], []),
 ('operation.get', ['spaceId','operationId'], []),
 ('operation.undo', ['spaceId','operationId','undoOperationId'], []),
 ('operation.reconcile', ['spaceId','operationId'], []),
 ('operation.prune', ['spaceId','operationIds'], []),
 ('resource.hold', ['spaceId','id'], ['targets','resources']),
 ('resource.hold.get', ['spaceId','id'], []),
 ('resource.hold.renew', ['spaceId','id'], []),
 ('resource.release', ['spaceId','id'], []), ('resource.collect', ['spaceId'], []),
 ('context.get', ['spaceId'], []),
 ('context.set', ['spaceId','operationId','base','binding'], []),
 ('context.preview', ['spaceId'], []),
]
block = source.split('export const contentMethods = {', 1)[1].split('\n};', 1)[0]
registered = re.findall(r'^\s*(["\w.]+):\s*\{\s*params:', block, re.M)
registered = [name.strip('"') for name in registered]
expected = [name for name, _, _ in spec]
if registered != expected:
    raise SystemExit('contentMethods registration differs from extractor manifest; update manifest from source.')
methods = [{'method': name, 'required': required, 'optional': optional}
           for name, required, optional in spec]
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps({'methods': methods}, ensure_ascii=False, indent=2) + '\n')
print(f'Wrote {len(methods)} methods to {out}')
